package com.spinthewheel.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wheelId: Long,
    val wheelName: String,
    val itemId: Long,
    val itemName: String,
    val itemLogoType: String,
    val itemLogoData: String,
    val itemColor: Long,
    val timestamp: Long = System.currentTimeMillis()
)
