package com.spinthewheel.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PillText = Color(0xFF0011FF)
private val PillFace = Color(0xFFF8F8FD)
private val PillBorder = Color(0xFF8B93F8)
private val PillBorderPressed = Color(0xFF646FFF)
private val PillShadow = Color(0xFF1F35FF)

/**
 * Pill button from Uiverse.io (by KhelVers): #f8f8fd face, #0011ff bold text,
 * fully rounded, thick #8b93f8 border and a hard #1f35ff shadow underneath.
 * On press the face drops down onto the shadow and the border darkens.
 *
 * Drop-in replacement for Material's Button(onClick, modifier, enabled) { ... }.
 * [compact] uses a thinner border / shorter shadow for dialogs and dense rows.
 */
@Composable
fun PillButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    compact: Boolean = false,
    content: @Composable RowScope.() -> Unit
) {
    val depth: Dp = if (compact) 4.dp else 8.dp
    val borderWidth: Dp = if (compact) 3.dp else 6.dp
    val padding = if (compact) PaddingValues(horizontal = 20.dp, vertical = 8.dp)
    else PaddingValues(horizontal = 36.dp, vertical = 14.dp)
    val shape = RoundedCornerShape(percent = 50)

    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val isDown = pressed && enabled
    val dy by animateDpAsState(if (isDown) depth else 0.dp, tween(60), label = "pillDrop")
    val borderColor by animateColorAsState(
        if (isDown) PillBorderPressed else PillBorder, tween(60), label = "pillBorder"
    )

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.5f)
            .padding(bottom = depth),
        propagateMinConstraints = true
    ) {
        // Hard shadow: same pill shape, sits `depth` lower and vanishes when pressed.
        if (!isDown) {
            Box(
                Modifier
                    .matchParentSize()
                    .offset(y = depth)
                    .background(PillShadow, shape)
            )
        }
        Box(
            modifier = Modifier
                .offset(y = dy)
                .background(PillFace, shape)
                .border(borderWidth, borderColor, shape)
                .clickable(
                    interactionSource = interaction,
                    indication = null,
                    enabled = enabled,
                    role = Role.Button,
                    onClick = onClick
                )
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            CompositionLocalProvider(LocalContentColor provides PillText) {
                ProvideTextStyle(
                    LocalTextStyle.current.merge(
                        TextStyle(
                            fontWeight = FontWeight.Bold,
                            fontSize = if (compact) 15.sp else 18.sp,
                            color = PillText
                        )
                    )
                ) {
                    Row(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        content = content
                    )
                }
            }
        }
    }
}
