package com.spinthewheel.app.util

import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity
import com.spinthewheel.app.data.repository.WheelRepository
import org.json.JSONArray
import org.json.JSONObject

data class ImportedWheel(
    val name: String,
    val description: String,
    val items: List<ImportedItem>
)

data class ImportedItem(
    val name: String,
    val color: Long,
    val logoType: String,
    val logoData: String
)

object JsonExportImport {

    fun exportWheel(wheel: WheelEntity, items: List<ItemEntity>): String {
        val root = JSONObject()
        val wheelObj = JSONObject().apply {
            put("name", wheel.name)
            put("description", wheel.description)
        }
        val itemsArr = JSONArray()
        items.forEach { item ->
            itemsArr.put(
                JSONObject().apply {
                    put("name", item.name)
                    put("color", colorToHex(item.color))
                    put("logoType", item.logoType)
                    put("logoData", item.logoData)
                }
            )
        }
        root.put("wheel", wheelObj)
        root.put("items", itemsArr)
        return root.toString(2)
    }

    fun exportAllWheels(wheels: List<Pair<WheelEntity, List<ItemEntity>>>): String {
        val root = JSONObject()
        val wheelsArr = JSONArray()
        wheels.forEach { (wheel, items) ->
            wheelsArr.put(JSONObject(exportWheel(wheel, items)))
        }
        root.put("wheels", wheelsArr)
        return root.toString(2)
    }

    /** Returns null if the JSON is malformed or doesn't match the expected shape. */
    fun parseImport(json: String): List<ImportedWheel>? {
        return try {
            val root = JSONObject(json)
            when {
                root.has("wheels") -> {
                    val arr = root.getJSONArray("wheels")
                    (0 until arr.length()).mapNotNull { parseSingleWheelObject(arr.getJSONObject(it)) }
                }
                root.has("wheel") -> listOfNotNull(parseSingleWheelObject(root))
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseSingleWheelObject(obj: JSONObject): ImportedWheel? {
        return try {
            val wheelObj = obj.getJSONObject("wheel")
            val name = wheelObj.getString("name")
            val description = wheelObj.optString("description", "")
            val itemsArr = obj.optJSONArray("items") ?: JSONArray()
            val items = (0 until itemsArr.length()).mapNotNull { i ->
                val itemObj = itemsArr.optJSONObject(i) ?: return@mapNotNull null
                val itemName = itemObj.optString("name").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val colorHex = itemObj.optString("color", "#3E7BFA")
                val color = hexToColorLong(colorHex) ?: 0xFF3E7BFA
                val logoType = itemObj.optString("logoType", "emoji")
                val logoData = itemObj.optString("logoData", "🎯")
                ImportedItem(itemName, color, logoType, logoData)
            }
            if (name.isBlank()) null else ImportedWheel(name, description, items)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun importWheels(repository: WheelRepository, wheels: List<ImportedWheel>) {
        wheels.forEach { imported ->
            val wheelId = repository.createWheel(imported.name, imported.description)
            val items = imported.items.mapIndexed { index, item ->
                ItemEntity(
                    wheelId = wheelId,
                    name = item.name,
                    color = item.color,
                    logoType = item.logoType,
                    logoData = item.logoData,
                    position = index
                )
            }
            if (items.isNotEmpty()) repository.addItems(items)
        }
    }
}
