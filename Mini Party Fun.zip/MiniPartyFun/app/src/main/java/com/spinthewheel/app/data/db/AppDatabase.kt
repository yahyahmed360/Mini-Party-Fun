package com.spinthewheel.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.spinthewheel.app.data.db.dao.HistoryDao
import com.spinthewheel.app.data.db.dao.ItemDao
import com.spinthewheel.app.data.db.dao.WheelDao
import com.spinthewheel.app.data.db.entity.HistoryEntity
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity

@Database(
    entities = [WheelEntity::class, ItemEntity::class, HistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wheelDao(): WheelDao
    abstract fun itemDao(): ItemDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "spin_the_wheel.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
