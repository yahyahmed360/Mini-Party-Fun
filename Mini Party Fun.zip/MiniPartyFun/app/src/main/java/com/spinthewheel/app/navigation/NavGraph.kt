package com.spinthewheel.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.ui.components.BottomNavBar
import com.spinthewheel.app.ui.screens.HistoryScreen
import com.spinthewheel.app.ui.screens.ItemEditorScreen
import com.spinthewheel.app.ui.screens.ItemsScreen
import com.spinthewheel.app.ui.screens.SettingsScreen
import com.spinthewheel.app.ui.screens.WheelEditorScreen
import com.spinthewheel.app.ui.screens.WheelScreen
import kotlinx.coroutines.launch

/** Routes that show the bottom navigation bar — the four primary sections. */
private val topLevelRoutes = setOf(Screen.Wheel.route, Screen.Items.route, Screen.History.route, Screen.Settings.route)

@Composable
fun SpinTheWheelNavGraph(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = topLevelRoutes.contains(currentRoute)
    val scope = rememberCoroutineScope()

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavBar(currentRoute = currentRoute) { screen ->
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Wheel.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Wheel.route) {
                WheelScreen(
                    container = container,
                    onNavigateToEditor = { wheelId ->
                        navController.navigate(Screen.WheelEditor.createRoute(wheelId))
                    },
                    onNavigateToItemsTab = {
                        navController.navigate(Screen.Items.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            composable(Screen.Items.route) {
                ItemsScreen(
                    container = container,
                    onOpenWheel = { wheelId ->
                        // Selecting a wheel from Items switches the active wheel and
                        // hands control back to the Wheel tab, per the master spec.
                        scope.launch { container.settingsDataStore.setActiveWheelId(wheelId) }
                        navController.navigate(Screen.Wheel.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onEditWheel = { wheelId ->
                        navController.navigate(Screen.WheelEditor.createRoute(wheelId))
                    }
                )
            }

            composable(Screen.History.route) {
                HistoryScreen(container = container)
            }

            composable(Screen.Settings.route) {
                SettingsScreen(container = container)
            }

            composable(
                route = Screen.WheelEditor.route,
                arguments = listOf(navArgument("wheelId") { type = NavType.LongType })
            ) { backStackEntry ->
                val wheelId = backStackEntry.arguments?.getLong("wheelId") ?: 0L
                WheelEditorScreen(
                    wheelId = wheelId,
                    container = container,
                    onBack = { navController.popBackStack() },
                    onEditItem = { wId, itemId ->
                        navController.navigate(Screen.ItemEditor.createRoute(wId, itemId))
                    },
                    onWheelDeleted = {
                        navController.navigate(Screen.Items.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(
                route = Screen.ItemEditor.route,
                arguments = listOf(
                    navArgument("wheelId") { type = NavType.LongType },
                    navArgument("itemId") { type = NavType.LongType }
                )
            ) { backStackEntry ->
                val wheelId = backStackEntry.arguments?.getLong("wheelId") ?: 0L
                val itemId = backStackEntry.arguments?.getLong("itemId") ?: 0L
                ItemEditorScreen(
                    wheelId = wheelId,
                    itemId = itemId,
                    container = container,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
