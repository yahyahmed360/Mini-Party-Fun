package com.spinthewheel.app.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class GrokResult {
    data class Success(val imageUrlOrBase64: String, val isBase64: Boolean) : GrokResult()
    data class Failure(val message: String) : GrokResult()
}

/**
 * Thin client around the xAI (Grok) image generation endpoint.
 * Base URL and model are configurable from Settings so this keeps working if
 * xAI changes their API surface without requiring a code change.
 *
 * Expected endpoint shape (xAI images API, OpenAI-compatible):
 *   POST {baseUrl}/images/generations
 *   Header: Authorization: Bearer {apiKey}
 *   Body: { "model": "...", "prompt": "...", "n": 1 }
 *   Response: { "data": [ { "url": "..." } ] }  OR  { "data": [ { "b64_json": "..." } ] }
 */
class GrokApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateItemLogo(
        baseUrl: String,
        model: String,
        apiKey: String,
        itemName: String,
        customPrompt: String?
    ): GrokResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext GrokResult.Failure("Grok API key not configured.")
        }

        val prompt = customPrompt?.takeIf { it.isNotBlank() }
            ?: "A simple, flat, minimal icon representing \"$itemName\", centered, single subject, " +
                "solid background, suitable as a small app icon, no text."

        val jsonBody = JSONObject().apply {
            put("model", model)
            put("prompt", prompt)
            put("n", 1)
            put("size", "512x512")
        }

        val body = jsonBody.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("${baseUrl.removeSuffix("/")}/images/generations")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val message = try {
                        JSONObject(responseBody).optJSONObject("error")?.optString("message")
                    } catch (e: Exception) {
                        null
                    } ?: "Grok request failed (HTTP ${response.code})."
                    return@withContext GrokResult.Failure(message)
                }

                val json = JSONObject(responseBody)
                val dataArray = json.optJSONArray("data")
                val first = dataArray?.optJSONObject(0)
                    ?: return@withContext GrokResult.Failure("Grok returned no image data.")

                val url = first.optString("url", "")
                if (url.isNotBlank()) {
                    return@withContext GrokResult.Success(url, isBase64 = false)
                }
                val b64 = first.optString("b64_json", "")
                if (b64.isNotBlank()) {
                    return@withContext GrokResult.Success(b64, isBase64 = true)
                }
                GrokResult.Failure("Grok response did not include an image.")
            }
        } catch (e: java.io.IOException) {
            GrokResult.Failure("Network error while contacting Grok: ${e.message ?: "unknown"}")
        } catch (e: Exception) {
            GrokResult.Failure("Unexpected error: ${e.message ?: "unknown"}")
        }
    }

    /** Downloads raw image bytes from a URL returned by the generation endpoint, for local caching. */
    suspend fun downloadImageBytes(url: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                response.body?.bytes()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Simple connectivity/auth check used by the Settings "Test Connection" button. */
    suspend fun testConnection(baseUrl: String, apiKey: String): GrokResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext GrokResult.Failure("Grok API key not configured.")
        val request = Request.Builder()
            .url("${baseUrl.removeSuffix("/")}/models")
            .addHeader("Authorization", "Bearer $apiKey")
            .get()
            .build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    GrokResult.Success("ok", isBase64 = false)
                } else {
                    GrokResult.Failure("Connection failed (HTTP ${response.code}).")
                }
            }
        } catch (e: Exception) {
            GrokResult.Failure("Could not reach Grok: ${e.message ?: "unknown"}")
        }
    }
}
