package com.spinthewheel.app.util

/**
 * Wheel item logos are always stored as a rendered glyph (emoji) or, for
 * AI-generated logos, a local file path — see [ItemEntity.logoType]. The
 * "Built-in icon" picker and the free-form "Emoji" picker both produce
 * logoType == "emoji"/"icon" glyphs so [WheelCanvas] can render every item
 * uniformly with a single, well-tested code path; the two pickers just offer
 * different browsing experiences (curated + labeled vs. full emoji search).
 */
object IconRegistry {

    /** Curated, labeled set shown in the "Built-in Icon" picker. */
    val builtInIcons: List<Pair<String, String>> = listOf(
        "Movie" to "🎬", "Music" to "🎵", "Game" to "🎮", "Sports" to "⚽",
        "Travel" to "✈️", "Food" to "🍔", "Coffee" to "☕", "Study" to "📚",
        "Work" to "💼", "Fitness" to "💪", "Health" to "❤️", "Home" to "🏠",
        "Pet" to "🐾", "Money" to "💰", "Gift" to "🎁", "Photo" to "📷",
        "Car" to "🚗", "Book" to "📖", "Nature" to "🌳", "Beach" to "🏖️",
        "Party" to "🎉", "Star" to "⭐", "Shopping" to "🛍️", "Sleep" to "😴"
    )

    /** Larger free-form set shown in the "Emoji" picker. */
    val emojiPalette: List<String> = listOf(
        "🍿", "🎮", "🍽️", "🥾", "📖", "🏋️", "☕", "✈️", "🍕", "🍣", "🍔", "🌮",
        "🍜", "🥗", "🏖️", "🖼️", "🌳", "🛍️", "🛋️", "🎓", "💻", "🖊️", "🖥️",
        "🧪", "✍️", "🗣️", "🏃", "🚴", "🧘", "🏊", "😴", "🤸", "❤️", "🗼",
        "🌴", "🏯", "🏛️", "🕌", "🏟️", "🏙️", "🌆", "👕", "👔", "🩳", "🧣",
        "🧥", "🧺", "🍽", "🧹", "🛒", "🗑️", "🧽", "📦", "✏️", "📷", "🎧",
        "🧵", "🎨", "🎁", "🌿", "🎟️", "💰", "📈", "🧾", "🎉", "🤲", "🏦",
        "🚶", "✨", "🎲", "🎯", "🎁", "🐶", "🐱", "🌸", "⭐", "🔥", "💡",
        "🎂", "🍰", "🍷", "🍺", "🚗", "🚀", "🏠", "🎸", "📱", "⏰", "🧭"
    )
}
