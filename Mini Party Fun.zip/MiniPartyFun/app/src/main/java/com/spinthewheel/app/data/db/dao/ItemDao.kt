package com.spinthewheel.app.data.db.dao

import androidx.room.*
import com.spinthewheel.app.data.db.entity.ItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemDao {
    @Query("SELECT * FROM items WHERE wheelId = :wheelId ORDER BY position ASC")
    fun observeItemsForWheel(wheelId: Long): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items ORDER BY wheelId ASC, position ASC")
    fun observeAllItems(): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items WHERE wheelId = :wheelId ORDER BY position ASC")
    suspend fun getItemsForWheel(wheelId: Long): List<ItemEntity>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getItemById(id: Long): ItemEntity?

    @Query("SELECT COUNT(*) FROM items WHERE wheelId = :wheelId")
    suspend fun countForWheel(wheelId: Long): Int

    @Insert
    suspend fun insert(item: ItemEntity): Long

    @Insert
    suspend fun insertAll(items: List<ItemEntity>): List<Long>

    @Update
    suspend fun update(item: ItemEntity)

    @Delete
    suspend fun delete(item: ItemEntity)

    @Query("DELETE FROM items WHERE wheelId = :wheelId")
    suspend fun deleteAllForWheel(wheelId: Long)
}
