package com.spinthewheel.app.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object ShareUtils {

    /**
     * Writes [json] to a temp file under the app's cache "exports/" directory
     * (declared in file_paths.xml) and launches Android's standard share sheet.
     */
    fun shareWheelJson(context: Context, wheelName: String, json: String) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = wheelName.trim().ifBlank { "wheel" }
            .replace(Regex("[^A-Za-z0-9-_ ]"), "").replace(" ", "_")
        val file = File(exportsDir, "${safeName}_${System.currentTimeMillis()}.json")
        FileOutputStream(file).use { it.write(json.toByteArray()) }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "$wheelName - Spin the Wheel export")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share wheel").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK.takeIf { context !is android.app.Activity } ?: 0)
        })
    }
}
