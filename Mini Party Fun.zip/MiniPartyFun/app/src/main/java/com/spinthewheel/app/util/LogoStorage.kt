package com.spinthewheel.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream

/**
 * Saves Grok-generated item logos to local storage, resized to a small
 * footprint so the wheel never ends up holding onto huge bitmaps. Also
 * provides an in-memory decode cache so a logo file is only ever read from
 * disk once per process (it's reused by the wheel, mini previews, item
 * lists, and the item editor).
 */
object LogoStorage {

    private const val TARGET_SIZE = 128
    private val memoryCache = LruCache<String, Bitmap>(40)

    private fun logosDir(context: Context): File =
        File(context.filesDir, "logos").apply { mkdirs() }

    /** Decodes + downsizes a base64-encoded image and saves it locally. Returns the file path. */
    fun saveFromBase64(context: Context, base64: String): String? {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            saveBitmap(context, bitmap)
        } catch (e: Exception) {
            null
        }
    }

    /** Downsizes and saves raw image bytes (e.g. downloaded from a URL). Returns the file path. */
    fun saveFromBytes(context: Context, bytes: ByteArray): String? {
        return try {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            saveBitmap(context, bitmap)
        } catch (e: Exception) {
            null
        }
    }

    private fun saveBitmap(context: Context, bitmap: Bitmap): String {
        val resized = Bitmap.createScaledBitmap(bitmap, TARGET_SIZE, TARGET_SIZE, true)
        val file = File(logosDir(context), "logo_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out -> resized.compress(Bitmap.CompressFormat.PNG, 90, out) }
        memoryCache.put(file.absolutePath, resized)
        return file.absolutePath
    }

    /** Returns the decoded bitmap for a stored logo path, using the in-memory cache. */
    fun get(path: String): Bitmap? {
        memoryCache.get(path)?.let { return it }
        return try {
            val file = File(path)
            if (!file.exists()) return null
            val bitmap = BitmapFactory.decodeFile(path) ?: return null
            memoryCache.put(path, bitmap)
            bitmap
        } catch (e: Exception) {
            null
        }
    }

    fun delete(path: String) {
        memoryCache.remove(path)
        try {
            File(path).delete()
        } catch (e: Exception) {
            // best-effort cleanup only
        }
    }
}
