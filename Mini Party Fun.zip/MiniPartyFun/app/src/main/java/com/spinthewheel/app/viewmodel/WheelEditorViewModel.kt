package com.spinthewheel.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spinthewheel.app.data.datastore.SettingsDataStore
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity
import com.spinthewheel.app.data.remote.GrokApiClient
import com.spinthewheel.app.data.remote.GrokResult
import com.spinthewheel.app.data.repository.WheelRepository
import com.spinthewheel.app.data.security.SecureKeyStore
import com.spinthewheel.app.util.LogoStorage
import com.spinthewheel.app.util.nextPaletteColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class WheelEditorUiState(
    val wheel: WheelEntity? = null,
    val items: List<ItemEntity> = emptyList(),
    val isLoading: Boolean = true
)

sealed class LogoGenState {
    object Idle : LogoGenState()
    object Loading : LogoGenState()
    data class Success(val resultUrlOrBase64: String, val isBase64: Boolean) : LogoGenState()
    data class Error(val message: String) : LogoGenState()
}

class WheelEditorViewModel(
    private val repository: WheelRepository,
    private val grokApiClient: GrokApiClient,
    private val secureKeyStore: SecureKeyStore,
    private val settings: SettingsDataStore,
    private val appContext: Context
) : ViewModel() {

    private var wheelId: Long = 0L

    private val _wheelFlowId = MutableStateFlow(0L)

    fun load(wheelId: Long) {
        this.wheelId = wheelId
        _wheelFlowId.value = wheelId
    }

    val uiState: StateFlow<WheelEditorUiState> = _wheelFlowId
        .flatMapLatest { id ->
            if (id == 0L) {
                flowOf(WheelEditorUiState(isLoading = false))
            } else {
                repository.observeWheelWithItems(id).map { withItems ->
                    WheelEditorUiState(
                        wheel = withItems?.wheel,
                        items = withItems?.items.orEmpty(),
                        isLoading = false
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WheelEditorUiState())

    private val _logoGenState = MutableStateFlow<LogoGenState>(LogoGenState.Idle)
    val logoGenState: StateFlow<LogoGenState> = _logoGenState

    fun renameWheel(newName: String) {
        val wheel = uiState.value.wheel ?: return
        viewModelScope.launch { repository.updateWheel(wheel.copy(name = newName)) }
    }

    fun addItem(name: String, color: Long? = null, logoType: String = "emoji", logoData: String = "🎯") {
        val currentWheelId = wheelId
        if (currentWheelId == 0L || name.isBlank()) return
        viewModelScope.launch {
            val count = uiState.value.items.size
            repository.addItem(
                ItemEntity(
                    wheelId = currentWheelId,
                    name = name,
                    color = color ?: nextPaletteColor(count),
                    logoType = logoType,
                    logoData = logoData,
                    position = count
                )
            )
        }
    }

    fun updateItem(item: ItemEntity) {
        viewModelScope.launch { repository.updateItem(item) }
    }

    fun deleteItem(item: ItemEntity) {
        viewModelScope.launch { repository.deleteItem(item) }
    }

    fun duplicateItem(item: ItemEntity) {
        viewModelScope.launch { repository.duplicateItem(item) }
    }

    fun moveItemUp(item: ItemEntity) {
        val items = uiState.value.items.sortedBy { it.position }
        val index = items.indexOfFirst { it.id == item.id }
        if (index <= 0) return
        val reordered = items.toMutableList()
        reordered[index] = items[index - 1]
        reordered[index - 1] = items[index]
        viewModelScope.launch { repository.reorderItems(reordered) }
    }

    fun moveItemDown(item: ItemEntity) {
        val items = uiState.value.items.sortedBy { it.position }
        val index = items.indexOfFirst { it.id == item.id }
        if (index == -1 || index >= items.size - 1) return
        val reordered = items.toMutableList()
        reordered[index] = items[index + 1]
        reordered[index + 1] = items[index]
        viewModelScope.launch { repository.reorderItems(reordered) }
    }

    fun clearItems() {
        val id = wheelId
        if (id == 0L) return
        viewModelScope.launch { repository.clearItems(id) }
    }

    fun deleteWheel(onDone: () -> Unit = {}) {
        val wheel = uiState.value.wheel ?: return
        viewModelScope.launch {
            repository.deleteWheel(wheel)
            onDone()
        }
    }

    fun generateLogo(itemName: String, customPrompt: String?) {
        viewModelScope.launch {
            _logoGenState.value = LogoGenState.Loading
            val apiKey = secureKeyStore.getGrokApiKey().orEmpty()
            var baseUrl = "https://api.x.ai/v1"
            var model = "grok-2-image"
            try {
                val snapshot = settings.settingsFlow.first()
                baseUrl = snapshot.grokApiBaseUrl
                model = snapshot.grokModel
            } catch (e: Exception) {
                // fall back to defaults above
            }
            when (val result = grokApiClient.generateItemLogo(baseUrl, model, apiKey, itemName, customPrompt)) {
                is GrokResult.Success -> _logoGenState.value = LogoGenState.Success(result.imageUrlOrBase64, result.isBase64)
                is GrokResult.Failure -> _logoGenState.value = LogoGenState.Error(result.message)
            }
        }
    }

    fun resetLogoGenState() {
        _logoGenState.value = LogoGenState.Idle
    }

    /**
     * Downloads (if needed), resizes, and saves the currently-generated logo to
     * local storage. Returns the saved file path, or null on failure — callers
     * should fall back to built-in icons/emoji if this returns null.
     */
    suspend fun persistGeneratedLogo(): String? {
        val state = _logoGenState.value
        if (state !is LogoGenState.Success) return null
        return withContext(Dispatchers.IO) {
            if (state.isBase64) {
                LogoStorage.saveFromBase64(appContext, state.resultUrlOrBase64)
            } else {
                val bytes = grokApiClient.downloadImageBytes(state.resultUrlOrBase64)
                bytes?.let { LogoStorage.saveFromBytes(appContext, it) }
            }
        }
    }
}
