package com.spinthewheel.app.data

import android.content.Context
import com.spinthewheel.app.data.datastore.SettingsDataStore
import com.spinthewheel.app.data.db.AppDatabase
import com.spinthewheel.app.data.remote.GrokApiClient
import com.spinthewheel.app.data.repository.WheelRepository
import com.spinthewheel.app.data.security.SecureKeyStore

/**
 * Lightweight, hand-rolled dependency container (no DI framework needed for
 * an app this size). Created once and reused by every ViewModel.
 */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext

    private val database = AppDatabase.getInstance(context)

    val repository = WheelRepository(
        wheelDao = database.wheelDao(),
        itemDao = database.itemDao(),
        historyDao = database.historyDao()
    )

    val settingsDataStore = SettingsDataStore(context)
    val secureKeyStore = SecureKeyStore(context)
    val grokApiClient = GrokApiClient()

    companion object {
        @Volatile private var INSTANCE: AppContainer? = null

        fun getInstance(context: Context): AppContainer {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppContainer(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
