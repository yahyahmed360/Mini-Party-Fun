package com.spinthewheel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spinthewheel.app.data.datastore.AppSettings
import com.spinthewheel.app.data.datastore.SettingsDataStore
import com.spinthewheel.app.data.remote.GrokApiClient
import com.spinthewheel.app.data.remote.GrokResult
import com.spinthewheel.app.data.repository.WheelRepository
import com.spinthewheel.app.data.security.SecureKeyStore
import com.spinthewheel.app.util.JsonExportImport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class GrokTestState {
    object Idle : GrokTestState()
    object Testing : GrokTestState()
    object Success : GrokTestState()
    data class Failed(val message: String) : GrokTestState()
}

class SettingsViewModel(
    private val repository: WheelRepository,
    private val settings: SettingsDataStore,
    private val secureKeyStore: SecureKeyStore,
    private val grokApiClient: GrokApiClient
) : ViewModel() {

    val settingsState: StateFlow<AppSettings> = settings.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _hasGrokKey = MutableStateFlow(secureKeyStore.hasGrokApiKey())
    val hasGrokKey: StateFlow<Boolean> = _hasGrokKey

    private val _grokTestState = MutableStateFlow<GrokTestState>(GrokTestState.Idle)
    val grokTestState: StateFlow<GrokTestState> = _grokTestState

    fun setDarkMode(value: Boolean) = viewModelScope.launch { settings.setDarkMode(value) }
    fun setAccentColor(name: String) = viewModelScope.launch { settings.setAccentColorName(name) }
    fun setAnimationsEnabled(value: Boolean) = viewModelScope.launch { settings.setAnimationsEnabled(value) }
    fun setSpinDuration(seconds: Float) = viewModelScope.launch { settings.setSpinDuration(seconds) }
    fun setSpinSoundEnabled(value: Boolean) = viewModelScope.launch { settings.setSpinSoundEnabled(value) }
    fun setVibrationEnabled(value: Boolean) = viewModelScope.launch { settings.setVibrationEnabled(value) }
    fun setShowItemNames(value: Boolean) = viewModelScope.launch { settings.setShowItemNames(value) }
    fun setShowItemLogos(value: Boolean) = viewModelScope.launch { settings.setShowItemLogos(value) }
    fun setGrokBaseUrl(value: String) = viewModelScope.launch { settings.setGrokBaseUrl(value) }
    fun setGrokModel(value: String) = viewModelScope.launch { settings.setGrokModel(value) }

    fun saveGrokApiKey(key: String) {
        secureKeyStore.saveGrokApiKey(key)
        _hasGrokKey.value = secureKeyStore.hasGrokApiKey()
        _grokTestState.value = GrokTestState.Idle
    }

    fun clearGrokApiKey() {
        secureKeyStore.clearGrokApiKey()
        _hasGrokKey.value = false
        _grokTestState.value = GrokTestState.Idle
    }

    fun testGrokConnection() {
        viewModelScope.launch {
            _grokTestState.value = GrokTestState.Testing
            val apiKey = secureKeyStore.getGrokApiKey().orEmpty()
            val baseUrl = settings.settingsFlow.first().grokApiBaseUrl
            when (val result = grokApiClient.testConnection(baseUrl, apiKey)) {
                is GrokResult.Success -> _grokTestState.value = GrokTestState.Success
                is GrokResult.Failure -> _grokTestState.value = GrokTestState.Failed(result.message)
            }
        }
    }

    suspend fun exportAllWheelsJson(): String {
        val wheels = repository.observeWheelsWithItems().first()
        return JsonExportImport.exportAllWheels(wheels.map { it.wheel to it.items })
    }

    suspend fun exportWheelJson(wheelId: Long): String? {
        val withItems = repository.observeWheelWithItems(wheelId).first() ?: return null
        return JsonExportImport.exportWheel(withItems.wheel, withItems.items)
    }

    fun importWheelsFromJson(json: String, onResult: (success: Boolean, count: Int) -> Unit) {
        viewModelScope.launch {
            val parsed = JsonExportImport.parseImport(json)
            if (parsed.isNullOrEmpty()) {
                onResult(false, 0)
                return@launch
            }
            JsonExportImport.importWheels(repository, parsed)
            onResult(true, parsed.size)
        }
    }

    fun clearAllData() {
        viewModelScope.launch { repository.clearAllData() }
    }
}
