package com.spinthewheel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spinthewheel.app.data.datastore.SettingsDataStore
import com.spinthewheel.app.data.db.entity.HistoryEntity
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity
import com.spinthewheel.app.data.repository.WheelRepository
import com.spinthewheel.app.util.JsonExportImport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

data class SpinPlan(
    val fromRotation: Float,
    val toRotation: Float,
    val winningItem: ItemEntity
)

data class WheelUiState(
    val allWheels: List<WheelEntity> = emptyList(),
    val activeWheel: WheelEntity? = null,
    val items: List<ItemEntity> = emptyList(),
    val currentResultText: String = "Spin the wheel",
    val currentResultEmoji: String = "",
    val isLoading: Boolean = true
)

class WheelViewModel(
    private val repository: WheelRepository,
    private val settings: SettingsDataStore
) : ViewModel() {

    private val activeWheelId = settings.settingsFlow.map { it.activeWheelId }

    val uiState: StateFlow<WheelUiState> = combine(
        repository.observeWheels(),
        activeWheelId
    ) { wheels, activeId -> wheels to activeId }
        .flatMapLatest { (wheels, activeId) ->
            val resolvedId = if (wheels.any { it.id == activeId }) activeId else wheels.firstOrNull()?.id ?: 0L
            if (resolvedId == 0L) {
                flowOf(WheelUiState(allWheels = wheels, activeWheel = null, items = emptyList(), isLoading = false))
            } else {
                repository.observeWheelWithItems(resolvedId).map { withItems ->
                    val wheel = withItems?.wheel
                    val items = withItems?.items.orEmpty()
                    val resultItem = wheel?.lastResultItemId?.let { id -> items.find { it.id == id } }
                    WheelUiState(
                        allWheels = wheels,
                        activeWheel = wheel,
                        items = items,
                        currentResultText = resultItem?.name ?: "Spin the wheel",
                        currentResultEmoji = resultItem?.logoData?.takeIf { resultItem.logoType == "emoji" || resultItem.logoType == "icon" } ?: "",
                        isLoading = false
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WheelUiState())

    private val _isSpinning = MutableStateFlow(false)
    val isSpinning: StateFlow<Boolean> = _isSpinning

    fun setActiveWheel(wheelId: Long) {
        viewModelScope.launch { settings.setActiveWheelId(wheelId) }
    }

    /** Computes a mathematically valid target rotation for a random winning item. Returns null if fewer than 2 items or already spinning. */
    fun prepareSpin(currentRotation: Float): SpinPlan? {
        val state = uiState.value
        if (_isSpinning.value) return null
        val items = state.items
        if (items.size < 2) return null

        val winningIndex = Random.nextInt(items.size)
        val winningItem = items[winningIndex]
        val segmentWidth = 360f / items.size
        val jitter = (Random.nextFloat() - 0.5f) * (segmentWidth * 0.6f)
        val itemCenterAngle = winningIndex * segmentWidth + segmentWidth / 2f + jitter

        // Pointer is fixed at the top (0 degrees). After rotating the wheel by R,
        // the segment now under the pointer is the one whose original angle
        // satisfies (angle + R) mod 360 == 0, i.e. angle == (360 - R mod 360) mod 360.
        val targetMod = (360f - itemCenterAngle).mod(360f)
        val currentMod = currentRotation.mod(360f)
        var delta = targetMod - currentMod
        if (delta < 0f) delta += 360f

        val extraSpins = 5 + Random.nextInt(3) // 5-7 full rotations for a satisfying spin
        val toRotation = currentRotation + delta + extraSpins * 360f

        _isSpinning.value = true
        return SpinPlan(fromRotation = currentRotation, toRotation = toRotation, winningItem = winningItem)
    }

    fun completeSpin(plan: SpinPlan) {
        val wheel = uiState.value.activeWheel
        if (wheel == null) {
            _isSpinning.value = false
            return
        }
        viewModelScope.launch {
            repository.markWheelUsed(wheel.id, plan.winningItem.id)
            repository.addHistoryEntry(
                HistoryEntity(
                    wheelId = wheel.id,
                    wheelName = wheel.name,
                    itemId = plan.winningItem.id,
                    itemName = plan.winningItem.name,
                    itemLogoType = plan.winningItem.logoType,
                    itemLogoData = plan.winningItem.logoData,
                    itemColor = plan.winningItem.color
                )
            )
            _isSpinning.value = false
        }
    }

    fun cancelSpinState() {
        _isSpinning.value = false
    }

    fun renameWheel(newName: String) {
        val wheel = uiState.value.activeWheel ?: return
        viewModelScope.launch { repository.updateWheel(wheel.copy(name = newName)) }
    }

    fun duplicateActiveWheel(onDone: (Long?) -> Unit = {}) {
        val wheel = uiState.value.activeWheel ?: return
        viewModelScope.launch { onDone(repository.duplicateWheel(wheel.id)) }
    }

    fun clearItems() {
        val wheel = uiState.value.activeWheel ?: return
        viewModelScope.launch { repository.clearItems(wheel.id) }
    }

    fun deleteActiveWheel(onDone: () -> Unit = {}) {
        val wheel = uiState.value.activeWheel ?: return
        viewModelScope.launch {
            repository.deleteWheel(wheel)
            onDone()
        }
    }

    fun resetWheel() {
        val wheel = uiState.value.activeWheel ?: return
        viewModelScope.launch { repository.updateWheel(wheel.copy(lastResultItemId = null)) }
    }

    suspend fun exportActiveWheelJson(): String? {
        val wheel = uiState.value.activeWheel ?: return null
        val withItems = repository.observeWheelWithItems(wheel.id).first() ?: return null
        return JsonExportImport.exportWheel(withItems.wheel, withItems.items)
    }
}
