package com.spinthewheel.app.ui.screens

import com.spinthewheel.app.ui.components.PillButton
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.data.db.entity.WheelEntity
import com.spinthewheel.app.data.repository.WheelWithItems
import com.spinthewheel.app.ui.components.*
import com.spinthewheel.app.util.ShareUtils
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.ItemsViewModel
import com.spinthewheel.app.viewmodel.WheelFilter
import kotlinx.coroutines.launch

@Composable
fun ItemsScreen(
    container: AppContainer,
    onOpenWheel: (Long) -> Unit,
    onEditWheel: (Long) -> Unit
) {
    val viewModel: ItemsViewModel = viewModel(factory = AppViewModelFactory(container))
    val uiState by viewModel.uiState.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var showFilterSheet by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var menuForWheel by remember { mutableStateOf<WheelWithItems?>(null) }
    var renameTarget by remember { mutableStateOf<WheelEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<WheelEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.height(12.dp))
        if (uiState.isSearchActive) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search wheels") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.setSearchActive(false) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Close search")
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Items", style = MaterialTheme.typography.headlineLarge)
                    Text(
                        "All your wheels",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    RoundIconButton(Icons.Filled.Search) { viewModel.setSearchActive(true) }
                    Spacer(Modifier.width(8.dp))
                    RoundIconButton(Icons.Filled.FilterList) { showFilterSheet = true }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (uiState.wheels.isEmpty() && !uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Filled.List, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text(
                    if (uiState.searchQuery.isNotBlank()) "No wheels match \"${uiState.searchQuery}\"" else "No wheels yet",
                    style = MaterialTheme.typography.titleLarge
                )
                if (uiState.searchQuery.isBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Create your first wheel and start spinning.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    PillButton(onClick = { showCreateDialog = true }) { Text("Create Wheel") }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(uiState.wheels, key = { it.wheel.id }) { wheelWithItems ->
                    WheelGridCard(
                        wheelWithItems = wheelWithItems,
                        onClick = { onOpenWheel(wheelWithItems.wheel.id) },
                        onMenuClick = { menuForWheel = wheelWithItems }
                    )
                }
                item(key = "create_new") {
                    CreateNewWheelCard(onClick = { showCreateDialog = true })
                }
            }
        }
    }

    if (showFilterSheet) {
        FilterSheet(
            current = uiState.filter,
            onSelect = { viewModel.setFilter(it) },
            onDismiss = { showFilterSheet = false }
        )
    }

    if (showCreateDialog) {
        CreateWheelDialog(
            onCreate = { name ->
                viewModel.createWheel(name) { newId -> onEditWheel(newId) }
                showCreateDialog = false
            },
            onDismiss = { showCreateDialog = false }
        )
    }

    menuForWheel?.let { wheelWithItems ->
        val wheel = wheelWithItems.wheel
        OneUiActionSheet(
            title = wheel.name,
            actions = listOf(
                SheetAction("Open", Icons.Filled.PlayArrow) { onOpenWheel(wheel.id) },
                SheetAction("Edit", Icons.Filled.Edit) { onEditWheel(wheel.id) },
                SheetAction("Rename", Icons.Filled.DriveFileRenameOutline) { renameTarget = wheel },
                SheetAction("Duplicate", Icons.Filled.ContentCopy) { viewModel.duplicateWheel(wheel.id) },
                SheetAction("Share", Icons.Filled.Share) {
                    scope.launch {
                        val json = com.spinthewheel.app.util.JsonExportImport.exportWheel(wheel, wheelWithItems.items)
                        ShareUtils.shareWheelJson(context, wheel.name, json)
                    }
                },
                SheetAction("Delete", Icons.Filled.Delete, isDestructive = true) { deleteTarget = wheel }
            ),
            onDismiss = { menuForWheel = null }
        )
    }

    renameTarget?.let { wheel ->
        TextPromptDialog(
            title = "Rename Wheel",
            initialValue = wheel.name,
            onConfirm = { newName -> viewModel.renameWheel(wheel, newName); renameTarget = null; menuForWheel = null },
            onDismiss = { renameTarget = null; menuForWheel = null }
        )
    }

    deleteTarget?.let { wheel ->
        ConfirmDialog(
            title = "Delete this wheel?",
            message = "\"${wheel.name}\" and all of its items will be permanently deleted.",
            confirmText = "Delete",
            onConfirm = { viewModel.deleteWheel(wheel); deleteTarget = null; menuForWheel = null },
            onDismiss = { deleteTarget = null; menuForWheel = null }
        )
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surface)
    ) {
        Icon(icon, contentDescription = null)
    }
}

@Composable
private fun WheelGridCard(
    wheelWithItems: WheelWithItems,
    onClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.05f)
                .padding(18.dp),
            contentAlignment = Alignment.Center
        ) {
            WheelMiniPreview(items = wheelWithItems.items, size = 300.dp, modifier = Modifier.fillMaxSize())
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    wheelWithItems.wheel.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Text(
                    "${wheelWithItems.items.size} Items",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onMenuClick, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Wheel options")
            }
        }
    }
}

@Composable
private fun CreateNewWheelCard(onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.8f)
            .clip(RoundedCornerShape(24.dp))
            .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(8.dp))
        Text("Create New", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(current: WheelFilter, onSelect: (WheelFilter) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                "Filter Wheels",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            )
            WheelFilter.entries.forEach { filter ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(filter); onDismiss() }
                        .padding(horizontal = 24.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(filter.label, style = MaterialTheme.typography.bodyLarge)
                    if (filter == current) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateWheelDialog(onCreate: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Wheel", style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Wheel Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }, enabled = name.isNotBlank()) {
                Text("Add Item")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
