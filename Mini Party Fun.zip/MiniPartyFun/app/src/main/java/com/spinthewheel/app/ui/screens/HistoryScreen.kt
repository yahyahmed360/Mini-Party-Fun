package com.spinthewheel.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.data.db.entity.HistoryEntity
import com.spinthewheel.app.ui.components.ConfirmDialog
import com.spinthewheel.app.util.LogoStorage
import com.spinthewheel.app.util.formatHistoryTimestamp
import com.spinthewheel.app.util.toComposeColor
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.HistoryViewModel

@Composable
fun HistoryScreen(container: AppContainer) {
    val viewModel: HistoryViewModel = viewModel(factory = AppViewModelFactory(container))
    val history by viewModel.history.collectAsState()

    var showClearConfirm by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<HistoryEntity?>(null) }
    var detailEntry by remember { mutableStateOf<HistoryEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("History", style = MaterialTheme.typography.headlineLarge)
            if (history.isNotEmpty()) {
                TextButton(onClick = { showClearConfirm = true }) { Text("Clear History") }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (history.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(top = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text("No spins yet", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Your spin results will show up here.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history, key = { it.id }) { entry ->
                    HistoryRow(
                        entry = entry,
                        onClick = { detailEntry = entry },
                        onDelete = { deleteTarget = entry }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (showClearConfirm) {
        ConfirmDialog(
            title = "Clear all history?",
            message = "All past spin results will be permanently deleted.",
            confirmText = "Clear",
            onConfirm = { viewModel.clearHistory(); showClearConfirm = false },
            onDismiss = { showClearConfirm = false }
        )
    }

    deleteTarget?.let { entry ->
        ConfirmDialog(
            title = "Delete this entry?",
            message = "This spin result will be removed from your history.",
            confirmText = "Delete",
            onConfirm = { viewModel.deleteEntry(entry); deleteTarget = null },
            onDismiss = { deleteTarget = null }
        )
    }

    detailEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { detailEntry = null },
            title = { Text(entry.itemName) },
            text = {
                Column {
                    Text("Wheel: ${entry.wheelName}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(formatHistoryTimestamp(entry.timestamp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { detailEntry = null }) { Text("Close") } },
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HistoryRow(entry: HistoryEntity, onClick: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(entry.itemColor.toComposeColor()),
            contentAlignment = Alignment.Center
        ) {
            when (entry.itemLogoType) {
                "emoji", "icon" -> Text(entry.itemLogoData, style = MaterialTheme.typography.titleLarge)
                "ai" -> {
                    val bitmap = remember(entry.itemLogoData) { LogoStorage.get(entry.itemLogoData) }
                    if (bitmap != null) {
                        androidx.compose.foundation.Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.size(30.dp).clip(CircleShape)
                        )
                    }
                }
                else -> {}
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(entry.itemName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text(
                entry.wheelName,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        Text(
            formatHistoryTimestamp(entry.timestamp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Close, contentDescription = "Delete entry", modifier = Modifier.size(18.dp))
        }
    }
}
