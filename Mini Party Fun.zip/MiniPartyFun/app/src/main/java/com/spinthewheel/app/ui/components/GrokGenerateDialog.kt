package com.spinthewheel.app.ui.components

import com.spinthewheel.app.ui.components.PillButton
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.spinthewheel.app.viewmodel.LogoGenState

/**
 * "Generate Item Logo" dialog: shows the item name, an optional custom
 * prompt, a Generate button, a loading state, and — on success — a preview
 * with Use Logo / Regenerate / Cancel.
 */
@Composable
fun GrokGenerateDialog(
    itemName: String,
    state: LogoGenState,
    onGenerate: (customPrompt: String?) -> Unit,
    onUseLogo: () -> Unit,
    onDismiss: () -> Unit
) {
    var prompt by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(Modifier.padding(24.dp)) {
                Text("Generate Item Logo", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    itemName.ifBlank { "Untitled item" },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Custom description (optional)") },
                    placeholder = { Text("e.g. flat minimal icon, warm colors") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 3
                )

                Spacer(Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    when (state) {
                        is LogoGenState.Idle -> {
                            Text(
                                "Your generated logo will appear here",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        is LogoGenState.Loading -> {
                            CircularProgressIndicator()
                        }
                        is LogoGenState.Success -> {
                            if (state.isBase64) {
                                val bitmap = remember(state.resultUrlOrBase64) {
                                    try {
                                        val bytes = Base64.decode(state.resultUrlOrBase64, Base64.DEFAULT)
                                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                                    } catch (e: Exception) {
                                        null
                                    }
                                }
                                if (bitmap != null) {
                                    Image(bitmap = bitmap, contentDescription = "Generated logo")
                                } else {
                                    Text("Couldn't preview the generated image.", color = MaterialTheme.colorScheme.error)
                                }
                            } else {
                                AsyncImage(
                                    model = state.resultUrlOrBase64,
                                    contentDescription = "Generated logo",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                        is LogoGenState.Error -> {
                            Text(
                                state.message,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                when (state) {
                    is LogoGenState.Success -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(Modifier.weight(1f))
                            OutlinedButton(onClick = { onGenerate(prompt.ifBlank { null }) }) { Text("Regenerate") }
                            PillButton(compact = true, onClick = onUseLogo) { Text("Use Logo") }
                        }
                    }
                    is LogoGenState.Loading -> {
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = onDismiss) { Text("Cancel") }
                        }
                    }
                    else -> {
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(Modifier.width(8.dp))
                            PillButton(compact = true, onClick = { onGenerate(prompt.ifBlank { null }) }) { Text("Generate") }
                        }
                    }
                }
            }
        }
    }
}
