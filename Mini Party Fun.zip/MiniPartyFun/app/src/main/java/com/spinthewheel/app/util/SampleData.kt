package com.spinthewheel.app.util

import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity
import com.spinthewheel.app.data.repository.WheelRepository

data class SampleWheelDef(val name: String, val items: List<Pair<String, String>>) // name -> emoji

val sampleWheels = listOf(
    SampleWheelDef(
        "What to do?",
        listOf(
            "Movie Night" to "🍿", "Game Night" to "🎮", "Dinner Out" to "🍽️",
            "Go Hiking" to "🥾", "Read a Book" to "📖", "Workout" to "🏋️",
            "Coffee Time" to "☕", "Travel" to "✈️"
        )
    ),
    SampleWheelDef(
        "Where to eat?",
        listOf(
            "Pizza" to "🍕", "Sushi" to "🍣", "Burgers" to "🍔",
            "Tacos" to "🌮", "Ramen" to "🍜", "Salad" to "🥗"
        )
    ),
    SampleWheelDef(
        "Weekend Plan",
        listOf("Beach" to "🏖️", "Museum" to "🖼️", "Park" to "🌳", "Shopping" to "🛍️", "Stay In" to "🛋️")
    ),
    SampleWheelDef(
        "Study Topics",
        listOf(
            "Math" to "🎓", "Kotlin" to "💻", "History" to "🖊️",
            "Design" to "🖥️", "Physics" to "🧪", "Writing" to "✍️", "Languages" to "🗣️"
        )
    ),
    SampleWheelDef(
        "Workout Plan",
        listOf("Run" to "🏃", "Cycle" to "🚴", "Yoga" to "🧘", "Strength" to "🏋️", "Swim" to "🏊", "Rest" to "😴", "Stretch" to "🤸", "Cardio" to "❤️")
    ),
    SampleWheelDef(
        "Travel Destinations",
        listOf("Paris" to "🗼", "Bali" to "🌴", "Tokyo" to "🏯", "Cairo" to "🏛️", "Istanbul" to "🕌", "Rome" to "🏟️", "Dubai" to "🏙️", "Malaysia" to "🕌", "New York" to "🌆")
    ),
    SampleWheelDef(
        "What to Wear?",
        listOf("Casual" to "👕", "Formal" to "👔", "Sporty" to "🩳", "Cozy" to "🧣", "Modest Chic" to "🧕", "Layered" to "🧥")
    ),
    SampleWheelDef(
        "Daily Chores",
        listOf("Laundry" to "🧺", "Dishes" to "🍽️", "Vacuum" to "🧹", "Groceries" to "🛒", "Trash" to "🗑️", "Tidy Up" to "🧽", "Dust" to "🪶", "Organize" to "📦")
    ),
    SampleWheelDef(
        "Creative Ideas",
        listOf("Sketch" to "✏️", "Write a Poem" to "📖", "Photography" to "📷", "Music" to "🎧", "Craft" to "🧵", "Paint" to "🎨", "Design" to "🖥️")
    ),
    SampleWheelDef(
        "Gift Ideas",
        listOf("Book" to "📖", "Gadget" to "🎧", "Gift Card" to "🎁", "Plant" to "🌿", "Clothing" to "👕", "Experience" to "🎟️")
    ),
    SampleWheelDef(
        "Budget Plan",
        listOf("Save" to "💰", "Invest" to "📈", "Groceries" to "🛒", "Bills" to "🧾", "Fun Money" to "🎉", "Charity" to "🤲", "Emergency Fund" to "🏦")
    ),
    SampleWheelDef(
        "Date Night",
        listOf("Dinner" to "🍽️", "Movie" to "🍿", "Walk" to "🚶", "Game Night" to "🎮", "Stargazing" to "✨")
    )
)

suspend fun seedSampleWheelsIfEmpty(repository: WheelRepository) {
    if (repository.countWheels() > 0) return
    sampleWheels.forEach { def ->
        val wheelId = repository.createWheel(def.name)
        val items = def.items.mapIndexed { index, (name, emoji) ->
            ItemEntity(
                wheelId = wheelId,
                name = name,
                color = nextPaletteColor(index),
                logoType = "emoji",
                logoData = emoji,
                position = index
            )
        }
        repository.addItems(items)
    }
}
