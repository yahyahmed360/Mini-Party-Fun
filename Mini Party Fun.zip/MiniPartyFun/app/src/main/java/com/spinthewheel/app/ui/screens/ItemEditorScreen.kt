package com.spinthewheel.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.ui.components.*
import com.spinthewheel.app.util.LogoStorage
import com.spinthewheel.app.util.nextPaletteColor
import com.spinthewheel.app.util.toComposeColor
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.LogoGenState
import com.spinthewheel.app.viewmodel.WheelEditorViewModel
import kotlinx.coroutines.launch

/**
 * Handles both "Add Item" (itemId == 0L) and "Edit Item" (itemId > 0). All
 * fields are held as local pending state and only committed to the database
 * when Save is pressed, so a Grok generation started while adding a brand
 * new item works the same way as when editing an existing one.
 */
@Composable
fun ItemEditorScreen(
    wheelId: Long,
    itemId: Long,
    container: AppContainer,
    onBack: () -> Unit
) {
    val viewModel: WheelEditorViewModel = viewModel(factory = AppViewModelFactory(container))
    LaunchedEffect(wheelId) { viewModel.load(wheelId) }
    val uiState by viewModel.uiState.collectAsState()
    val logoGenState by viewModel.logoGenState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isNewItem = itemId == 0L
    val existingItem = remember(uiState.items, itemId) { uiState.items.find { it.id == itemId } }

    var name by remember(itemId) { mutableStateOf(existingItem?.name ?: "") }
    var color by remember(itemId) { mutableStateOf(existingItem?.color ?: nextPaletteColor(uiState.items.size)) }
    var logoType by remember(itemId) { mutableStateOf(existingItem?.logoType ?: "emoji") }
    var logoData by remember(itemId) { mutableStateOf(existingItem?.logoData ?: "🎯") }
    var initialized by remember(itemId) { mutableStateOf(existingItem != null || isNewItem) }

    // Once the existing item loads asynchronously, seed the fields exactly once.
    LaunchedEffect(existingItem) {
        if (!isNewItem && existingItem != null && !initialized) {
            name = existingItem.name
            color = existingItem.color
            logoType = existingItem.logoType
            logoData = existingItem.logoData
            initialized = true
        }
    }

    var showColorPicker by remember { mutableStateOf(false) }
    var showChangeLogoSheet by remember { mutableStateOf(false) }
    var showEmojiPicker by remember { mutableStateOf(false) }
    var showIconPicker by remember { mutableStateOf(false) }
    var showGrokDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isSavingLogo by remember { mutableStateOf(false) }

    fun save() {
        if (name.isBlank()) return
        if (isNewItem) {
            viewModel.addItem(name.trim(), color, logoType, logoData)
        } else {
            existingItem?.let {
                viewModel.updateItem(it.copy(name = name.trim(), color = color, logoType = logoType, logoData = logoData))
            }
        }
        onBack()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                if (isNewItem) "Add Item" else "Edit Item",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
            if (!isNewItem) {
                IconButton(onClick = { showDeleteConfirm = true }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete item", tint = androidx.compose.ui.graphics.Color(0xFFFF5449))
                }
            }
            IconButton(onClick = { save() }, enabled = name.isNotBlank()) {
                Icon(Icons.Filled.Check, contentDescription = "Save", tint = MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Live logo + color preview
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(color.toComposeColor()),
                contentAlignment = Alignment.Center
            ) {
                when (logoType) {
                    "emoji", "icon" -> Text(logoData, style = MaterialTheme.typography.displaySmall)
                    "ai" -> {
                        val bitmap = remember(logoData) { LogoStorage.get(logoData) }
                        if (bitmap != null) {
                            Image(bitmap = bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.size(84.dp).clip(CircleShape))
                        } else {
                            Icon(Icons.Filled.Image, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    else -> Icon(Icons.Filled.Casino, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(36.dp))
                }
            }

            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Item Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))

            SectionLabel("Item Color")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { showColorPicker = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color.toComposeColor())
                )
                Spacer(Modifier.width(14.dp))
                Text(com.spinthewheel.app.util.colorToHex(color), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(20.dp))

            SectionLabel("Item Logo")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { showChangeLogoSheet = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Change Logo", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(40.dp))
        }
    }

    if (showColorPicker) {
        ColorPickerDialog(
            currentColor = color,
            onColorSelected = { color = it; showColorPicker = false },
            onDismiss = { showColorPicker = false }
        )
    }

    if (showChangeLogoSheet) {
        ChangeLogoSheet(
            hasExistingLogo = logoType != "none",
            onPickEmoji = { showEmojiPicker = true },
            onPickIcon = { showIconPicker = true },
            onGenerateAi = { viewModel.resetLogoGenState(); showGrokDialog = true },
            onRemove = { logoType = "none"; logoData = "" },
            onDismiss = { showChangeLogoSheet = false }
        )
    }

    if (showEmojiPicker) {
        EmojiPickerDialog(
            onEmojiSelected = { logoType = "emoji"; logoData = it },
            onDismiss = { showEmojiPicker = false }
        )
    }

    if (showIconPicker) {
        IconPickerDialog(
            onIconSelected = { logoType = "icon"; logoData = it },
            onDismiss = { showIconPicker = false }
        )
    }

    if (showGrokDialog) {
        GrokGenerateDialog(
            itemName = name,
            state = logoGenState,
            onGenerate = { prompt -> viewModel.generateLogo(name.ifBlank { "wheel item" }, prompt) },
            onUseLogo = {
                if (!isSavingLogo) {
                    isSavingLogo = true
                    scope.launch {
                        val path = viewModel.persistGeneratedLogo()
                        isSavingLogo = false
                        if (path != null) {
                            logoType = "ai"
                            logoData = path
                            showGrokDialog = false
                            viewModel.resetLogoGenState()
                        }
                    }
                }
            },
            onDismiss = { showGrokDialog = false; viewModel.resetLogoGenState() }
        )
    }

    if (showDeleteConfirm && existingItem != null) {
        ConfirmDialog(
            title = "Delete this item?",
            message = "\"${existingItem.name}\" will be removed from the wheel.",
            confirmText = "Delete",
            onConfirm = { viewModel.deleteItem(existingItem); showDeleteConfirm = false; onBack() },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}
