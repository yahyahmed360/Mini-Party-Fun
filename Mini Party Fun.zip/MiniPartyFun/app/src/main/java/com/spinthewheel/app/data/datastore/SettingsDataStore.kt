package com.spinthewheel.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

data class AppSettings(
    val darkMode: Boolean = true,
    val accentColorName: String = "Blue",
    val animationsEnabled: Boolean = true,
    val spinDurationSeconds: Float = 4f,
    val spinSoundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val showItemNames: Boolean = true,
    val showItemLogos: Boolean = true,
    val activeWheelId: Long = 0L,
    val grokApiBaseUrl: String = "https://api.x.ai/v1",
    val grokModel: String = "grok-2-image"
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val ACCENT = stringPreferencesKey("accent_color_name")
        val ANIMATIONS = booleanPreferencesKey("animations_enabled")
        val SPIN_DURATION = floatPreferencesKey("spin_duration_seconds")
        val SPIN_SOUND = booleanPreferencesKey("spin_sound_enabled")
        val VIBRATION = booleanPreferencesKey("vibration_enabled")
        val SHOW_NAMES = booleanPreferencesKey("show_item_names")
        val SHOW_LOGOS = booleanPreferencesKey("show_item_logos")
        val ACTIVE_WHEEL = longPreferencesKey("active_wheel_id")
        val GROK_BASE_URL = stringPreferencesKey("grok_base_url")
        val GROK_MODEL = stringPreferencesKey("grok_model")
    }

    val settingsFlow = context.dataStore.data.map { prefs ->
        AppSettings(
            darkMode = prefs[Keys.DARK_MODE] ?: true,
            accentColorName = prefs[Keys.ACCENT] ?: "Blue",
            animationsEnabled = prefs[Keys.ANIMATIONS] ?: true,
            spinDurationSeconds = prefs[Keys.SPIN_DURATION] ?: 4f,
            spinSoundEnabled = prefs[Keys.SPIN_SOUND] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION] ?: true,
            showItemNames = prefs[Keys.SHOW_NAMES] ?: true,
            showItemLogos = prefs[Keys.SHOW_LOGOS] ?: true,
            activeWheelId = prefs[Keys.ACTIVE_WHEEL] ?: 0L,
            grokApiBaseUrl = prefs[Keys.GROK_BASE_URL] ?: "https://api.x.ai/v1",
            grokModel = prefs[Keys.GROK_MODEL] ?: "grok-2-image"
        )
    }

    suspend fun setDarkMode(value: Boolean) = context.dataStore.edit { it[Keys.DARK_MODE] = value }
    suspend fun setAccentColorName(value: String) = context.dataStore.edit { it[Keys.ACCENT] = value }
    suspend fun setAnimationsEnabled(value: Boolean) = context.dataStore.edit { it[Keys.ANIMATIONS] = value }
    suspend fun setSpinDuration(value: Float) = context.dataStore.edit { it[Keys.SPIN_DURATION] = value }
    suspend fun setSpinSoundEnabled(value: Boolean) = context.dataStore.edit { it[Keys.SPIN_SOUND] = value }
    suspend fun setVibrationEnabled(value: Boolean) = context.dataStore.edit { it[Keys.VIBRATION] = value }
    suspend fun setShowItemNames(value: Boolean) = context.dataStore.edit { it[Keys.SHOW_NAMES] = value }
    suspend fun setShowItemLogos(value: Boolean) = context.dataStore.edit { it[Keys.SHOW_LOGOS] = value }
    suspend fun setActiveWheelId(value: Long) = context.dataStore.edit { it[Keys.ACTIVE_WHEEL] = value }
    suspend fun setGrokBaseUrl(value: String) = context.dataStore.edit { it[Keys.GROK_BASE_URL] = value }
    suspend fun setGrokModel(value: String) = context.dataStore.edit { it[Keys.GROK_MODEL] = value }
}
