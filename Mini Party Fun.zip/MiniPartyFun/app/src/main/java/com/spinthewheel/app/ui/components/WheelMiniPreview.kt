package com.spinthewheel.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import com.spinthewheel.app.data.db.entity.ItemEntity

@Composable
fun WheelMiniPreview(
    items: List<ItemEntity>,
    size: Dp,
    modifier: Modifier = Modifier
) {
    WheelCanvas(
        items = items,
        rotationDegrees = 0f,
        size = size,
        showNames = false,
        showLogos = true,
        modifier = modifier
    )
}
