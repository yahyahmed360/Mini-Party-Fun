package com.spinthewheel.app.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the Grok/xAI API key using an Android Keystore-backed master key plus
 * EncryptedSharedPreferences (AES-256-GCM for values, AES-256-SIV for keys).
 * The raw key never touches plain SharedPreferences, source code, or logs.
 */
class SecureKeyStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveGrokApiKey(key: String) {
        prefs.edit().putString(KEY_GROK_API_KEY, key).apply()
    }

    fun getGrokApiKey(): String? = prefs.getString(KEY_GROK_API_KEY, null)

    fun clearGrokApiKey() {
        prefs.edit().remove(KEY_GROK_API_KEY).apply()
    }

    fun hasGrokApiKey(): Boolean = !getGrokApiKey().isNullOrBlank()

    companion object {
        private const val KEY_GROK_API_KEY = "grok_api_key"
    }
}
