package com.spinthewheel.app.ui.screens

import com.spinthewheel.app.ui.components.PillButton
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.ui.components.*
import com.spinthewheel.app.util.colorToHex
import com.spinthewheel.app.util.toComposeColor
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.WheelEditorViewModel

@Composable
fun WheelEditorScreen(
    wheelId: Long,
    container: AppContainer,
    onBack: () -> Unit,
    onEditItem: (wheelId: Long, itemId: Long) -> Unit,
    onWheelDeleted: () -> Unit
) {
    val viewModel: WheelEditorViewModel = viewModel(factory = AppViewModelFactory(container))
    LaunchedEffect(wheelId) { viewModel.load(wheelId) }
    val uiState by viewModel.uiState.collectAsState()

    var showOverflowMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var menuForItem by remember { mutableStateOf<ItemEntity?>(null) }
    var deleteItemTarget by remember { mutableStateOf<ItemEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Edit Wheel", style = MaterialTheme.typography.titleLarge)
                Text(
                    uiState.wheel?.let { "${it.name} · ${uiState.items.size} Items" } ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { showOverflowMenu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More options")
            }
        }

        Spacer(Modifier.height(12.dp))

        Box(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), contentAlignment = Alignment.Center) {
            WheelMiniPreview(items = uiState.items, size = 180.dp)
        }

        Spacer(Modifier.height(8.dp))

        if (uiState.items.isEmpty() && !uiState.isLoading) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text("No items", style = MaterialTheme.typography.titleMedium)
                Text("Add some items to start spinning.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(uiState.items.sortedBy { it.position }, key = { it.id }) { item ->
                    ItemRow(
                        item = item,
                        onClick = { onEditItem(wheelId, item.id) },
                        onMenuClick = { menuForItem = item }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }

        Spacer(Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
            PillButton(
                onClick = { onEditItem(wheelId, 0L) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add Item")
            }
        }
    }

    if (showOverflowMenu) {
        OneUiActionSheet(
            title = uiState.wheel?.name,
            actions = listOf(
                SheetAction("Rename Wheel", Icons.Filled.DriveFileRenameOutline) { showRenameDialog = true },
                SheetAction("Clear Items", Icons.Filled.PlaylistRemove) { showClearConfirm = true },
                SheetAction("Delete Wheel", Icons.Filled.Delete, isDestructive = true) { showDeleteConfirm = true }
            ),
            onDismiss = { showOverflowMenu = false }
        )
    }

    if (showRenameDialog) {
        TextPromptDialog(
            title = "Rename Wheel",
            initialValue = uiState.wheel?.name.orEmpty(),
            onConfirm = { newName -> viewModel.renameWheel(newName); showRenameDialog = false },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showClearConfirm) {
        ConfirmDialog(
            title = "Clear all items?",
            message = "This removes every item from this wheel. This can't be undone.",
            confirmText = "Clear",
            onConfirm = { viewModel.clearItems(); showClearConfirm = false },
            onDismiss = { showClearConfirm = false }
        )
    }

    if (showDeleteConfirm) {
        val wheel = uiState.wheel
        ConfirmDialog(
            title = "Delete this wheel?",
            message = "\"${wheel?.name}\" and all of its items will be permanently deleted.",
            confirmText = "Delete",
            onConfirm = {
                viewModel.deleteWheel { onWheelDeleted() }
                showDeleteConfirm = false
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    menuForItem?.let { item ->
        OneUiActionSheet(
            title = item.name,
            actions = listOf(
                SheetAction("Edit", Icons.Filled.Edit) { onEditItem(wheelId, item.id) },
                SheetAction("Move Up", Icons.Filled.ArrowUpward) { viewModel.moveItemUp(item) },
                SheetAction("Move Down", Icons.Filled.ArrowDownward) { viewModel.moveItemDown(item) },
                SheetAction("Duplicate", Icons.Filled.ContentCopy) { viewModel.duplicateItem(item) },
                SheetAction("Delete", Icons.Filled.Delete, isDestructive = true) { deleteItemTarget = item }
            ),
            onDismiss = { menuForItem = null }
        )
    }

    deleteItemTarget?.let { item ->
        ConfirmDialog(
            title = "Delete this item?",
            message = "\"${item.name}\" will be removed from the wheel.",
            confirmText = "Delete",
            onConfirm = { viewModel.deleteItem(item); deleteItemTarget = null; menuForItem = null },
            onDismiss = { deleteItemTarget = null; menuForItem = null }
        )
    }
}

@Composable
private fun ItemRow(item: ItemEntity, onClick: () -> Unit, onMenuClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(item.color.toComposeColor()),
            contentAlignment = Alignment.Center
        ) {
            ItemLogoGlyph(item)
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text(
                colorToHex(item.color),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onMenuClick) {
            Icon(Icons.Filled.MoreVert, contentDescription = "Item options")
        }
    }
}

@Composable
private fun ItemLogoGlyph(item: ItemEntity) {
    when (item.logoType) {
        "emoji", "icon" -> Text(item.logoData, style = MaterialTheme.typography.titleLarge)
        "ai" -> {
            val bitmap = remember(item.logoData) { com.spinthewheel.app.util.LogoStorage.get(item.logoData) }
            if (bitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(30.dp).clip(CircleShape)
                )
            } else {
                Icon(Icons.Filled.Image, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
            }
        }
        else -> {}
    }
}
