package com.spinthewheel.app.ui.screens

import com.spinthewheel.app.ui.components.PillButton
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.data.datastore.AppSettings
import com.spinthewheel.app.ui.components.*
import com.spinthewheel.app.util.FeedbackUtils
import com.spinthewheel.app.util.ShareUtils
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.WheelViewModel
import kotlinx.coroutines.launch

@Composable
fun WheelScreen(
    container: AppContainer,
    onNavigateToEditor: (Long) -> Unit,
    onNavigateToItemsTab: () -> Unit
) {
    val viewModel: WheelViewModel = viewModel(factory = AppViewModelFactory(container))
    val uiState by viewModel.uiState.collectAsState()
    val isSpinning by viewModel.isSpinning.collectAsState()
    val settings by container.settingsDataStore.settingsFlow.collectAsState(initial = AppSettings())
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val rotationAnim = remember { Animatable(0f) }

    var showOverflowMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    fun performSpin() {
        if (isSpinning) return
        val plan = viewModel.prepareSpin(rotationAnim.value) ?: return
        scope.launch {
            rotationAnim.animateTo(
                targetValue = plan.toRotation,
                animationSpec = tween(
                    durationMillis = (settings.spinDurationSeconds * 1000).toInt().coerceIn(1500, 10000),
                    easing = FastOutSlowInEasing
                )
            )
            viewModel.completeSpin(plan)
            if (settings.vibrationEnabled) FeedbackUtils.vibrate(context)
            if (settings.spinSoundEnabled) FeedbackUtils.playSpinResultTone()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Spin the Wheel", style = MaterialTheme.typography.headlineLarge)
            IconButton(
                onClick = { showOverflowMenu = true },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More options")
            }
        }

        Spacer(Modifier.height(16.dp))

        // Current Choice card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    "Current Choice",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    if (uiState.currentResultEmoji.isNotBlank())
                        "${uiState.currentResultText} ${uiState.currentResultEmoji}"
                    else uiState.currentResultText,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        if (uiState.allWheels.isEmpty() && !uiState.isLoading) {
            EmptyStateCard(
                title = "No wheels yet",
                message = "Create your first wheel and start spinning.",
                buttonText = "Create Wheel",
                onClick = onNavigateToItemsTab
            )
        } else {
            val screenWidth = LocalConfiguration.current.screenWidthDp.dp
            val wheelSize = (screenWidth - 40.dp).coerceAtMost(360.dp)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(contentAlignment = Alignment.Center) {
                    WheelCanvas(
                        items = uiState.items,
                        rotationDegrees = rotationAnim.value,
                        size = wheelSize,
                        showNames = settings.showItemNames,
                        showLogos = settings.showItemLogos
                    )

                    // Center SPIN button
                    Box(
                        modifier = Modifier
                            .size(wheelSize * 0.28f)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                            .clickable(enabled = uiState.items.size >= 2 && !isSpinning) { performSpin() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "SPIN",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    // Pointer, fixed at the top of the wheel
                    Icon(
                        Icons.Filled.LocationOn,
                        contentDescription = "Pointer",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-6).dp)
                            .size(36.dp)
                    )
                }
            }

            if (uiState.activeWheel != null && uiState.items.size < 2) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (uiState.items.isEmpty()) "No items — add some to start spinning." else "Add at least 2 items to spin.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(8.dp))
                PillButton(onClick = { uiState.activeWheel?.let { onNavigateToEditor(it.id) } }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Add Item")
                }
            }

            Spacer(Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("My Wheels", style = MaterialTheme.typography.titleLarge)
                TextButton(onClick = onNavigateToItemsTab) { Text("See All") }
            }
            Spacer(Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(uiState.allWheels) { wheel ->
                    val wheelItems = remember(wheel.id, uiState.items, uiState.activeWheel?.id) {
                        if (wheel.id == uiState.activeWheel?.id) uiState.items else emptyList()
                    }
                    Column(
                        modifier = Modifier
                            .width(96.dp)
                            .clickable { viewModel.setActiveWheel(wheel.id) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .border(
                                    width = if (wheel.id == uiState.activeWheel?.id) 2.dp else 0.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            WheelMiniPreview(items = wheelItems, size = 76.dp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            wheel.name,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
                item {
                    Column(
                        modifier = Modifier
                            .width(96.dp)
                            .clickable { onNavigateToItemsTab() },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Create new wheel", tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Create New", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }

    if (showOverflowMenu) {
        val wheel = uiState.activeWheel
        OneUiActionSheet(
            title = wheel?.name,
            actions = listOfNotNull(
                wheel?.let { SheetAction("Edit Wheel", Icons.Filled.Edit) { onNavigateToEditor(it.id) } },
                SheetAction("Rename Wheel", Icons.Filled.DriveFileRenameOutline) { showRenameDialog = true },
                SheetAction("Duplicate Wheel", Icons.Filled.ContentCopy) {
                    viewModel.duplicateActiveWheel { newId -> newId?.let { viewModel.setActiveWheel(it) } }
                },
                SheetAction("Clear Items", Icons.Filled.PlaylistRemove) { showClearConfirm = true },
                SheetAction("Reset Wheel", Icons.Filled.RestartAlt) { viewModel.resetWheel() },
                SheetAction("Share Wheel", Icons.Filled.Share) {
                    scope.launch {
                        val json = viewModel.exportActiveWheelJson()
                        if (json != null && wheel != null) ShareUtils.shareWheelJson(context, wheel.name, json)
                    }
                },
                SheetAction("Delete Wheel", Icons.Filled.Delete, isDestructive = true) { showDeleteConfirm = true }
            ),
            onDismiss = { showOverflowMenu = false }
        )
    }

    if (showRenameDialog) {
        TextPromptDialog(
            title = "Rename Wheel",
            initialValue = uiState.activeWheel?.name.orEmpty(),
            onConfirm = { newName -> viewModel.renameWheel(newName); showRenameDialog = false },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showClearConfirm) {
        ConfirmDialog(
            title = "Clear all items?",
            message = "This removes every item from \"${uiState.activeWheel?.name}\". This can't be undone.",
            confirmText = "Clear",
            onConfirm = { viewModel.clearItems(); showClearConfirm = false },
            onDismiss = { showClearConfirm = false }
        )
    }

    if (showDeleteConfirm) {
        ConfirmDialog(
            title = "Delete this wheel?",
            message = "\"${uiState.activeWheel?.name}\" and all of its items will be permanently deleted.",
            confirmText = "Delete",
            onConfirm = { viewModel.deleteActiveWheel(); showDeleteConfirm = false },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun EmptyStateCard(title: String, message: String, buttonText: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Filled.Casino,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        PillButton(onClick = onClick) { Text(buttonText) }
    }
}
