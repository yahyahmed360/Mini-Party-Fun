package com.spinthewheel.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

// logoType: "emoji", "icon", "ai", "none"
@Entity(
    tableName = "items",
    foreignKeys = [
        ForeignKey(
            entity = WheelEntity::class,
            parentColumns = ["id"],
            childColumns = ["wheelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("wheelId")]
)
data class ItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wheelId: Long,
    val name: String,
    val color: Long,
    val logoType: String = "emoji",
    val logoData: String = "🎯",
    val position: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
