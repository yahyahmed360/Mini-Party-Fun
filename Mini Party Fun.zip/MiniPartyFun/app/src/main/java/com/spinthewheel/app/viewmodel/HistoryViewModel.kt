package com.spinthewheel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spinthewheel.app.data.db.entity.HistoryEntity
import com.spinthewheel.app.data.repository.WheelRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(private val repository: WheelRepository) : ViewModel() {

    val history: StateFlow<List<HistoryEntity>> = repository.observeHistory()
        .map { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteEntry(entry: HistoryEntity) {
        viewModelScope.launch { repository.deleteHistoryEntry(entry) }
    }

    fun clearHistory() {
        viewModelScope.launch { repository.clearHistory() }
    }
}
