package com.spinthewheel.app.util

import androidx.compose.ui.graphics.Color
import com.spinthewheel.app.ui.theme.ItemColorPaletteRaw

/** Picks the next palette color so consecutive items in a wheel don't repeat colors. */
fun nextPaletteColor(existingCount: Int): Long {
    return ItemColorPaletteRaw[existingCount % ItemColorPaletteRaw.size]
}

/**
 * Item/wheel colors are always stored as plain 0xAARRGGBB longs (the same
 * format as [colorToHex]/[hexToColorLong] and an ordinary literal like
 * 0xFF7C4DFF) — never Compose's internal 64-bit Color.value. Using the
 * standard Color(Long) constructor here is what makes a typed hex value and
 * a tapped palette swatch produce an identical, valid color.
 */
fun Long.toComposeColor(): Color = Color(this)

fun colorToHex(color: Long): String {
    val rgb = (color and 0xFFFFFFL).toString(16).padStart(6, '0')
    return "#${rgb.uppercase()}"
}

fun hexToColorLong(hex: String): Long? {
    val cleaned = hex.trim().removePrefix("#")
    if (cleaned.length != 6 && cleaned.length != 8) return null
    return try {
        val full = if (cleaned.length == 6) "FF$cleaned" else cleaned
        full.toLong(16)
    } catch (e: NumberFormatException) {
        null
    }
}
