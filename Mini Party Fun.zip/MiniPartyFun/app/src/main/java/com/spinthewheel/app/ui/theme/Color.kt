package com.spinthewheel.app.ui.theme

import androidx.compose.ui.graphics.Color

// One UI inspired dark palette
val OneUiBackground = Color(0xFF0B0D14)
val OneUiSurface = Color(0xFF161822)
val OneUiSurfaceAlt = Color(0xFF1E212C)
val OneUiSurfaceRaised = Color(0xFF23273A)
val OneUiOutline = Color(0xFF2A2E3E)
val OneUiTextPrimary = Color(0xFFF5F6FA)
val OneUiTextSecondary = Color(0xFFA6ACC2)

// Light counterpart, used only when the user disables Dark Mode in Settings.
val OneUiBackgroundLight = Color(0xFFF1F2F7)
val OneUiSurfaceLight = Color(0xFFFFFFFF)
val OneUiSurfaceAltLight = Color(0xFFE8EAF1)
val OneUiTextPrimaryLight = Color(0xFF14161E)
val OneUiTextSecondaryLight = Color(0xFF696F80)

val AccentBlue = Color(0xFF3E7BFA)
val AccentPurple = Color(0xFF8B5CF6)
val AccentGreen = Color(0xFF34C77B)
val AccentOrange = Color(0xFFFF9F45)
val AccentPink = Color(0xFFEC4899)
val AccentTeal = Color(0xFF14B8B8)

val AccentOptions = listOf(
    "Blue" to AccentBlue,
    "Purple" to AccentPurple,
    "Green" to AccentGreen,
    "Orange" to AccentOrange,
    "Pink" to AccentPink,
    "Teal" to AccentTeal
)

val ItemColorPalette = listOf(
    0xFF3E7BFA,
    0xFF14B8C7,
    0xFF8B5CF6,
    0xFFEC4899,
    0xFFEF4444,
    0xFFFF9F45,
    0xFFF5C518,
    0xFF34C77B
).map { Color(it) }

/**
 * Same colors as [ItemColorPalette], as plain 0xAARRGGBB longs. Item/wheel
 * colors are always stored in this format (matching [colorToHex]/[hexToColorLong]
 * exactly) so a manually-typed hex value and a tapped palette swatch behave
 * identically — never store a Color's internal `.value` here.
 */
val ItemColorPaletteRaw = listOf(
    0xFF3E7BFAL, 0xFF14B8C7L, 0xFF8B5CF6L, 0xFFEC4899L,
    0xFFEF4444L, 0xFFFF9F45L, 0xFFF5C518L, 0xFF34C77BL
)
