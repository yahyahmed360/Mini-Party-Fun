package com.spinthewheel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spinthewheel.app.data.repository.WheelRepository
import com.spinthewheel.app.data.repository.WheelWithItems
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class WheelFilter(val label: String) {
    ALL("All"),
    RECENTLY_USED("Recently Used"),
    MOST_ITEMS("Most Items"),
    FEWEST_ITEMS("Fewest Items"),
    RECENTLY_CREATED("Recently Created"),
    ALPHABETICAL("Alphabetical")
}

data class ItemsUiState(
    val wheels: List<WheelWithItems> = emptyList(),
    val searchQuery: String = "",
    val isSearchActive: Boolean = false,
    val filter: WheelFilter = WheelFilter.ALL,
    val isLoading: Boolean = true
)

class ItemsViewModel(private val repository: WheelRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _isSearchActive = MutableStateFlow(false)
    private val _filter = MutableStateFlow(WheelFilter.ALL)

    val uiState: StateFlow<ItemsUiState> = combine(
        repository.observeWheelsWithItems(),
        _searchQuery,
        _isSearchActive,
        _filter
    ) { wheels, query, searchActive, filter ->
        val filtered = wheels.filter {
            query.isBlank() || it.wheel.name.contains(query, ignoreCase = true)
        }
        val sorted = when (filter) {
            WheelFilter.ALL -> filtered
            WheelFilter.RECENTLY_USED -> filtered.sortedByDescending { it.wheel.lastUsedAt }
            WheelFilter.MOST_ITEMS -> filtered.sortedByDescending { it.items.size }
            WheelFilter.FEWEST_ITEMS -> filtered.sortedBy { it.items.size }
            WheelFilter.RECENTLY_CREATED -> filtered.sortedByDescending { it.wheel.createdAt }
            WheelFilter.ALPHABETICAL -> filtered.sortedBy { it.wheel.name.lowercase() }
        }
        ItemsUiState(
            wheels = sorted,
            searchQuery = query,
            isSearchActive = searchActive,
            filter = filter,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ItemsUiState())

    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) _searchQuery.value = ""
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: WheelFilter) {
        _filter.value = filter
    }

    fun createWheel(name: String, description: String = "", onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createWheel(name, description)
            onCreated(id)
        }
    }

    fun renameWheel(wheel: com.spinthewheel.app.data.db.entity.WheelEntity, newName: String) {
        viewModelScope.launch { repository.updateWheel(wheel.copy(name = newName)) }
    }

    fun duplicateWheel(wheelId: Long, onDone: (Long?) -> Unit = {}) {
        viewModelScope.launch { onDone(repository.duplicateWheel(wheelId)) }
    }

    fun deleteWheel(wheel: com.spinthewheel.app.data.db.entity.WheelEntity) {
        viewModelScope.launch { repository.deleteWheel(wheel) }
    }
}
