package com.spinthewheel.app.data.db.dao

import androidx.room.*
import com.spinthewheel.app.data.db.entity.WheelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WheelDao {
    @Query("SELECT * FROM wheels ORDER BY createdAt ASC")
    fun observeWheels(): Flow<List<WheelEntity>>

    @Query("SELECT * FROM wheels WHERE id = :id")
    suspend fun getWheelById(id: Long): WheelEntity?

    @Query("SELECT COUNT(*) FROM wheels")
    suspend fun countWheels(): Int

    @Query("SELECT * FROM wheels WHERE id = :id")
    fun observeWheelById(id: Long): Flow<WheelEntity?>

    @Insert
    suspend fun insert(wheel: WheelEntity): Long

    @Update
    suspend fun update(wheel: WheelEntity)

    @Delete
    suspend fun delete(wheel: WheelEntity)

    @Query("DELETE FROM wheels")
    suspend fun deleteAll()
}
