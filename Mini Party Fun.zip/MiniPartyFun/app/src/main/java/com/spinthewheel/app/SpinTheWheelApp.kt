package com.spinthewheel.app

import android.app.Application
import com.miniparty.fungame.Prefs
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.util.seedSampleWheelsIfEmpty
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SpinTheWheelApp : Application() {

    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer.getInstance(this)
        appScope.launch {
            seedSampleWheelsIfEmpty(container.repository)
        }

        // The "More" tab (Mini Party Fun) keeps its own independent light/dark/system
        // theme preference. Applying it here at process start preserves its behavior
        // exactly as it worked in the standalone Mini Party Fun app.
        Prefs.applyThemeMode(Prefs.getThemeMode(this))
    }
}
