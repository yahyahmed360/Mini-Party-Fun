package com.spinthewheel.app.ui.components

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.util.LogoStorage
import com.spinthewheel.app.util.toComposeColor
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.min

/**
 * Draws the real spinning wheel. Segment order/colors/logos come directly from
 * [items] (the single source of truth), so any edit to an item is reflected here
 * immediately. [rotationDegrees] rotates the whole wheel clockwise; the pointer
 * that determines the winner is drawn separately and stays fixed at the top.
 *
 * logoType "emoji" and "icon" both store a renderable glyph in logoData and are
 * drawn as text. logoType "ai" stores a local file path to a Grok-generated PNG
 * (saved via [LogoStorage]) and is drawn as a bitmap.
 */
@Composable
fun WheelCanvas(
    items: List<ItemEntity>,
    rotationDegrees: Float,
    size: Dp,
    showNames: Boolean = true,
    showLogos: Boolean = true,
    modifier: Modifier = Modifier
) {
    // Decoded once per unique set of AI logo paths and reused across recompositions/frames.
    val aiLogoBitmaps: Map<Long, Bitmap> = remember(items.map { it.id to it.logoType to it.logoData }) {
        items.filter { it.logoType == "ai" && it.logoData.isNotBlank() }
            .mapNotNull { item -> LogoStorage.get(item.logoData)?.let { item.id to it } }
            .toMap()
    }

    val namePaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.LEFT
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }
    val logoPaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
    }

    Canvas(modifier = modifier.size(size)) {
        val diameter = min(this.size.width, this.size.height)
        val radius = diameter / 2f
        val center = androidx.compose.ui.geometry.Offset(this.size.width / 2f, this.size.height / 2f)

        // Outer ring
        drawCircle(color = Color(0xFF23273A), radius = radius, center = center)

        if (items.isEmpty()) {
            drawCircle(color = Color(0xFF1E212C), radius = radius * 0.92f, center = center)
            return@Canvas
        }

        val n = items.size
        val segmentSweep = 360f / n
        val ringPadding = radius * 0.045f
        val wheelRadius = radius - ringPadding

        drawContext.canvas.nativeCanvas.apply {
            save()
            rotate(rotationDegrees, center.x, center.y)

            items.forEachIndexed { index, item ->
                val startAngle = -90f + index * segmentSweep
                val itemColor = item.color.toComposeColor()

                val paint = Paint().apply {
                    isAntiAlias = true
                    color = itemColor.toArgb()
                    style = Paint.Style.FILL
                }
                val rect = android.graphics.RectF(
                    center.x - wheelRadius, center.y - wheelRadius,
                    center.x + wheelRadius, center.y + wheelRadius
                )
                drawArc(rect, startAngle, segmentSweep, true, paint)

                // Logo + name, drawn radially outward from the center of the segment.
                save()
                val midAngle = startAngle + segmentSweep / 2f
                rotate(midAngle, center.x, center.y)

                val textRadius = wheelRadius * 0.62f
                val logoSizePx = (wheelRadius * 0.16f).coerceIn(20f, 56f)

                if (showLogos && (item.logoType == "emoji" || item.logoType == "icon") && item.logoData.isNotBlank()) {
                    logoPaint.textSize = logoSizePx
                    drawText(
                        item.logoData,
                        center.x + textRadius - logoSizePx * 0.7f,
                        center.y + logoPaint.textSize / 3f,
                        logoPaint
                    )
                } else if (showLogos && item.logoType == "ai") {
                    aiLogoBitmaps[item.id]?.let { bmp ->
                        val half = logoSizePx
                        val destRect = android.graphics.RectF(
                            center.x + textRadius - half, center.y - half,
                            center.x + textRadius + half, center.y + half
                        )
                        val bmpPaint = Paint().apply { isAntiAlias = true }
                        drawBitmap(bmp, null, destRect, bmpPaint)
                    }
                }

                if (showNames && n <= 16) {
                    namePaint.color = android.graphics.Color.WHITE
                    namePaint.textSize = (wheelRadius * 0.085f).coerceIn(18f, 30f)
                    val maxChars = (segmentSweep / 6.5f).toInt().coerceIn(4, 16)
                    val label = if (item.name.length > maxChars) item.name.take(maxChars - 1) + "…" else item.name
                    drawText(
                        label,
                        center.x + textRadius + logoSizePx * 0.55f,
                        center.y + namePaint.textSize / 3f,
                        namePaint
                    )
                }
                restore()
            }
            restore()
        }

        // Thin separators between segments for a crisper look.
        drawContext.canvas.nativeCanvas.apply {
            save()
            rotate(rotationDegrees, center.x, center.y)
            val sepPaint = Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.argb(60, 0, 0, 0)
                strokeWidth = 2f
            }
            for (index in 0 until n) {
                val angleRad = Math.toRadians((-90f + index * segmentSweep).toDouble())
                val x = center.x + wheelRadius * cos(angleRad).toFloat()
                val y = center.y + wheelRadius * sin(angleRad).toFloat()
                drawLine(center.x, center.y, x, y, sepPaint)
            }
            restore()
        }

        // Outer border ring
        drawCircle(
            color = Color(0xFF14161E),
            radius = radius,
            center = center,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = radius * 0.045f)
        )
    }
}
