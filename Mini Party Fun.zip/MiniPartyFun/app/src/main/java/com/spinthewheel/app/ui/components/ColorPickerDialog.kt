package com.spinthewheel.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.spinthewheel.app.ui.theme.ItemColorPalette
import com.spinthewheel.app.ui.theme.ItemColorPaletteRaw
import com.spinthewheel.app.util.colorToHex
import com.spinthewheel.app.util.hexToColorLong
import com.spinthewheel.app.util.toComposeColor

@Composable
fun ColorPickerDialog(
    currentColor: Long,
    onColorSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selected by remember { mutableStateOf(currentColor) }
    var hexInput by remember { mutableStateOf(colorToHex(currentColor)) }
    var hexError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Item Color", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    modifier = Modifier.height(120.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ItemColorPalette.indices.toList()) { index ->
                        val color = ItemColorPalette[index]
                        val colorLong = ItemColorPaletteRaw[index]
                        val isSelected = colorsRoughlyEqual(colorLong, selected)
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = Color.White,
                                    shape = CircleShape
                                )
                                .clickable {
                                    selected = colorLong
                                    hexInput = colorToHex(colorLong)
                                    hexError = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(selected.toComposeColor())
                    )
                    Spacer(Modifier.width(12.dp))
                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { input ->
                            hexInput = input
                            val parsed = hexToColorLong(input)
                            if (parsed != null) {
                                hexError = false
                                selected = parsed
                            } else {
                                hexError = true
                            }
                        },
                        label = { Text("Hex color") },
                        placeholder = { Text("#7C4DFF") },
                        isError = hexError,
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (hexError) {
                    Text(
                        "Enter a valid hex color, e.g. #7C4DFF",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onColorSelected(selected) }, enabled = !hexError) {
                Text("Use Color")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

private fun colorsRoughlyEqual(a: Long, b: Long): Boolean =
    (a and 0xFFFFFFL) == (b and 0xFFFFFFL)
