package com.spinthewheel.app.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Formats a timestamp like "Today, 8:42 PM" / "Yesterday, 8:42 PM" / "Mar 4, 8:42 PM". */
fun formatHistoryTimestamp(timestamp: Long): String {
    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))

    val entryCal = Calendar.getInstance().apply { timeInMillis = timestamp }
    val todayCal = Calendar.getInstance()
    val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }

    return when {
        isSameDay(entryCal, todayCal) -> "Today, $time"
        isSameDay(entryCal, yesterdayCal) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(timestamp))
    }
}

private fun isSameDay(a: Calendar, b: Calendar): Boolean =
    a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
