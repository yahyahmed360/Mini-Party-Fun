package com.spinthewheel.app.ui.screens

import com.spinthewheel.app.ui.components.PillButton
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spinthewheel.app.BuildConfig
import com.spinthewheel.app.data.AppContainer
import com.spinthewheel.app.ui.components.ConfirmDialog
import com.spinthewheel.app.ui.theme.AccentOptions
import com.spinthewheel.app.viewmodel.AppViewModelFactory
import com.spinthewheel.app.viewmodel.GrokTestState
import com.spinthewheel.app.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun SettingsScreen(container: AppContainer) {
    val viewModel: SettingsViewModel = viewModel(factory = AppViewModelFactory(container))
    val settings by viewModel.settingsState.collectAsState()
    val hasGrokKey by viewModel.hasGrokKey.collectAsState()
    val grokTestState by viewModel.grokTestState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var apiKeyInput by remember { mutableStateOf("") }
    var showClearAllConfirm by remember { mutableStateOf(false) }
    var showClearKeyConfirm by remember { mutableStateOf(false) }
    var showAdvancedGrok by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showLicenses by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            snackbarMessage = null
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val json = viewModel.exportAllWheelsJson()
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                snackbarMessage = "Backup saved."
            } catch (e: Exception) {
                snackbarMessage = "Couldn't save the backup file."
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val text = context.contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream)).readText()
            }
            if (text != null) {
                viewModel.importWheelsFromJson(text) { success, count ->
                    snackbarMessage = if (success) "Imported $count wheel(s)." else "That file couldn't be imported — check the format."
                }
            }
        } catch (e: Exception) {
            snackbarMessage = "Couldn't read that file."
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Text("Settings", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(20.dp))

            SettingsSection("Appearance") {
                SwitchRow("Dark Mode", settings.darkMode) { viewModel.setDarkMode(it) }
                Spacer(Modifier.height(12.dp))
                Text("Accent Color", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(bottom = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccentOptions.forEach { (accentName, accentColor) ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                                .border(
                                    width = if (settings.accentColorName == accentName) 3.dp else 0.dp,
                                    color = Color.White,
                                    shape = CircleShape
                                )
                                .clickable { viewModel.setAccentColor(accentName) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (settings.accentColorName == accentName) {
                                Icon(Icons.Filled.Check, contentDescription = accentName, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                SwitchRow("Animations", settings.animationsEnabled) { viewModel.setAnimationsEnabled(it) }
            }

            SettingsSection("Wheel") {
                Text(
                    "Spin Duration: ${settings.spinDurationSeconds.toInt()}s",
                    style = MaterialTheme.typography.bodyLarge
                )
                Slider(
                    value = settings.spinDurationSeconds,
                    onValueChange = { viewModel.setSpinDuration(it) },
                    valueRange = 2f..8f,
                    steps = 5
                )
                SwitchRow("Spin Sound", settings.spinSoundEnabled) { viewModel.setSpinSoundEnabled(it) }
                SwitchRow("Vibration", settings.vibrationEnabled) { viewModel.setVibrationEnabled(it) }
                SwitchRow("Show Item Names", settings.showItemNames) { viewModel.setShowItemNames(it) }
                SwitchRow("Show Item Logos", settings.showItemLogos) { viewModel.setShowItemLogos(it) }
            }

            SettingsSection("AI") {
                Text("Grok AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (hasGrokKey) "API key configured." else "Grok API key not configured.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("Grok API Key") },
                    placeholder = { Text(if (hasGrokKey) "•••••••••••••••• (saved)" else "xai-...") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(compact = true, onClick = {
                        if (apiKeyInput.isNotBlank()) {
                            viewModel.saveGrokApiKey(apiKeyInput.trim())
                            apiKeyInput = ""
                            snackbarMessage = "API key saved securely."
                        }
                    }, enabled = apiKeyInput.isNotBlank()) { Text("Save") }
                    OutlinedButton(onClick = { viewModel.testGrokConnection() }, enabled = hasGrokKey && grokTestState !is GrokTestState.Testing) {
                        Text("Test Connection")
                    }
                    OutlinedButton(onClick = { showClearKeyConfirm = true }, enabled = hasGrokKey) { Text("Clear Key") }
                }
                when (val test = grokTestState) {
                    is GrokTestState.Testing -> {
                        Spacer(Modifier.height(8.dp))
                        Text("Testing connection…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    is GrokTestState.Success -> {
                        Spacer(Modifier.height(8.dp))
                        Text("Connection successful.", color = Color(0xFF34C759), style = MaterialTheme.typography.bodySmall)
                    }
                    is GrokTestState.Failed -> {
                        Spacer(Modifier.height(8.dp))
                        Text(test.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    else -> {}
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = { showAdvancedGrok = !showAdvancedGrok }) {
                    Text(if (showAdvancedGrok) "Hide advanced options" else "Advanced (base URL & model)")
                }
                if (showAdvancedGrok) {
                    var baseUrl by remember(settings.grokApiBaseUrl) { mutableStateOf(settings.grokApiBaseUrl) }
                    var model by remember(settings.grokModel) { mutableStateOf(settings.grokModel) }
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { baseUrl = it },
                        label = { Text("API Base URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PillButton(compact = true, onClick = {
                        viewModel.setGrokBaseUrl(baseUrl.trim())
                        viewModel.setGrokModel(model.trim())
                        snackbarMessage = "Grok settings updated."
                    }) { Text("Save Advanced Settings") }
                }
            }

            SettingsSection("Data") {
                SettingsClickRow("Backup", Icons.Filled.CloudUpload) {
                    exportLauncher.launch("spin_the_wheel_backup_${System.currentTimeMillis()}.json")
                }
                SettingsClickRow("Restore", Icons.Filled.CloudDownload) {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                }
                SettingsClickRow("Export Wheels", Icons.Filled.FileUpload) {
                    exportLauncher.launch("spin_the_wheel_export_${System.currentTimeMillis()}.json")
                }
                SettingsClickRow("Import Wheels", Icons.Filled.FileDownload) {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                }
                SettingsClickRow("Clear All Data", Icons.Filled.DeleteForever, isDestructive = true) {
                    showClearAllConfirm = true
                }
            }

            SettingsSection("About") {
                SettingsClickRow("App Version", Icons.Filled.Info, showChevron = false) {}
                Text(
                    BuildConfig.VERSION_NAME,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )
                SettingsClickRow("Privacy", Icons.Filled.PrivacyTip) { showAbout = true }
                SettingsClickRow("Open Source Licenses", Icons.Filled.Description) { showLicenses = true }
            }

            Spacer(Modifier.height(32.dp))
        }
    }

    if (showClearAllConfirm) {
        ConfirmDialog(
            title = "Clear all data?",
            message = "Every wheel, item, and history entry will be permanently deleted. This can't be undone.",
            confirmText = "Clear Everything",
            onConfirm = { viewModel.clearAllData(); showClearAllConfirm = false; snackbarMessage = "All data cleared." },
            onDismiss = { showClearAllConfirm = false }
        )
    }

    if (showClearKeyConfirm) {
        ConfirmDialog(
            title = "Clear Grok API key?",
            message = "You'll need to re-enter it to generate AI logos again.",
            confirmText = "Clear",
            onConfirm = { viewModel.clearGrokApiKey(); showClearKeyConfirm = false; snackbarMessage = "API key cleared." },
            onDismiss = { showClearKeyConfirm = false }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Privacy") },
            text = {
                Text(
                    "Spin the Wheel stores your wheels, items, and history locally on your device. " +
                        "Your Grok API key is encrypted with the Android Keystore and never leaves your device " +
                        "except to call the configured xAI endpoint when you generate a logo."
                )
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") } },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showLicenses) {
        AlertDialog(
            onDismissRequest = { showLicenses = false },
            title = { Text("Open Source Licenses") },
            text = {
                Column {
                    listOf(
                        "AndroidX & Jetpack Compose — Apache 2.0",
                        "Kotlin Coroutines — Apache 2.0",
                        "Room — Apache 2.0",
                        "OkHttp — Apache 2.0",
                        "Coil — Apache 2.0"
                    ).forEach { Text("• $it", modifier = Modifier.padding(vertical = 2.dp)) }
                }
            },
            confirmButton = { TextButton(onClick = { showLicenses = false }) { Text("Close") } },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 10.dp)
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        content = content
    )
    Spacer(Modifier.height(24.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsClickRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDestructive: Boolean = false,
    showChevron: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val tint = if (isDestructive) Color(0xFFFF5449) else MaterialTheme.colorScheme.onSurface
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = tint, modifier = Modifier.weight(1f))
        if (showChevron) {
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
