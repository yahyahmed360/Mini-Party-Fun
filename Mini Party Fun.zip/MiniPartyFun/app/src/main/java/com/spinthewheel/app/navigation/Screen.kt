package com.spinthewheel.app.navigation

sealed class Screen(val route: String) {
    object Wheel : Screen("wheel")
    object Items : Screen("items")
    object History : Screen("history")
    object Settings : Screen("settings")
    object WheelEditor : Screen("wheel_editor/{wheelId}") {
        fun createRoute(wheelId: Long) = "wheel_editor/$wheelId"
    }
    object ItemEditor : Screen("item_editor/{wheelId}/{itemId}") {
        fun createRoute(wheelId: Long, itemId: Long) = "item_editor/$wheelId/$itemId"
    }
}

