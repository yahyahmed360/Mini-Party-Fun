package com.spinthewheel.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.spinthewheel.app.data.AppContainer

class AppViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return when {
            modelClass.isAssignableFrom(WheelViewModel::class.java) ->
                WheelViewModel(container.repository, container.settingsDataStore) as T
            modelClass.isAssignableFrom(ItemsViewModel::class.java) ->
                ItemsViewModel(container.repository) as T
            modelClass.isAssignableFrom(WheelEditorViewModel::class.java) ->
                WheelEditorViewModel(container.repository, container.grokApiClient, container.secureKeyStore, container.settingsDataStore, container.appContext) as T
            modelClass.isAssignableFrom(HistoryViewModel::class.java) ->
                HistoryViewModel(container.repository) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(container.repository, container.settingsDataStore, container.secureKeyStore, container.grokApiClient) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
