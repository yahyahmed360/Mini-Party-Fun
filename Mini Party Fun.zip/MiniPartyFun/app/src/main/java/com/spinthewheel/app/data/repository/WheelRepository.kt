package com.spinthewheel.app.data.repository

import com.spinthewheel.app.data.db.dao.HistoryDao
import com.spinthewheel.app.data.db.dao.ItemDao
import com.spinthewheel.app.data.db.dao.WheelDao
import com.spinthewheel.app.data.db.entity.HistoryEntity
import com.spinthewheel.app.data.db.entity.ItemEntity
import com.spinthewheel.app.data.db.entity.WheelEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class WheelWithItems(
    val wheel: WheelEntity,
    val items: List<ItemEntity>
)

class WheelRepository(
    private val wheelDao: WheelDao,
    private val itemDao: ItemDao,
    private val historyDao: HistoryDao
) {
    fun observeWheels(): Flow<List<WheelEntity>> = wheelDao.observeWheels()

    fun observeItemsForWheel(wheelId: Long): Flow<List<ItemEntity>> =
        itemDao.observeItemsForWheel(wheelId)

    fun observeWheelWithItems(wheelId: Long): Flow<WheelWithItems?> =
        combine(wheelDao.observeWheelById(wheelId), itemDao.observeItemsForWheel(wheelId)) { wheel, items ->
            wheel?.let { WheelWithItems(it, items) }
        }

    fun observeHistory(): Flow<List<HistoryEntity>> = historyDao.observeHistory()

    fun observeWheelsWithItems(): Flow<List<WheelWithItems>> =
        combine(wheelDao.observeWheels(), itemDao.observeAllItems()) { wheels, items ->
            wheels.map { wheel -> WheelWithItems(wheel, items.filter { it.wheelId == wheel.id }) }
        }

    suspend fun getWheelById(id: Long): WheelEntity? = wheelDao.getWheelById(id)

    suspend fun countWheels(): Int = wheelDao.countWheels()

    suspend fun getItemsForWheel(wheelId: Long): List<ItemEntity> = itemDao.getItemsForWheel(wheelId)

    suspend fun createWheel(name: String, description: String = ""): Long =
        wheelDao.insert(WheelEntity(name = name, description = description))

    suspend fun updateWheel(wheel: WheelEntity) =
        wheelDao.update(wheel.copy(updatedAt = System.currentTimeMillis()))

    suspend fun deleteWheel(wheel: WheelEntity) = wheelDao.delete(wheel)

    suspend fun markWheelUsed(wheelId: Long, resultItemId: Long) {
        wheelDao.getWheelById(wheelId)?.let {
            wheelDao.update(
                it.copy(
                    lastUsedAt = System.currentTimeMillis(),
                    lastResultItemId = resultItemId
                )
            )
        }
    }

    suspend fun duplicateWheel(wheelId: Long): Long? {
        val original = wheelDao.getWheelById(wheelId) ?: return null
        val newId = wheelDao.insert(
            original.copy(id = 0, name = "${original.name} (Copy)", createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis(), lastResultItemId = null)
        )
        val originalItems = itemDao.getItemsForWheel(wheelId)
        itemDao.insertAll(originalItems.map { it.copy(id = 0, wheelId = newId) })
        return newId
    }

    suspend fun clearItems(wheelId: Long) = itemDao.deleteAllForWheel(wheelId)

    suspend fun addItem(item: ItemEntity): Long = itemDao.insert(item)

    suspend fun addItems(items: List<ItemEntity>) = itemDao.insertAll(items)

    suspend fun updateItem(item: ItemEntity) = itemDao.update(item.copy(updatedAt = System.currentTimeMillis()))

    suspend fun deleteItem(item: ItemEntity) = itemDao.delete(item)

    suspend fun duplicateItem(item: ItemEntity): Long {
        val count = itemDao.countForWheel(item.wheelId)
        return itemDao.insert(item.copy(id = 0, name = "${item.name} (Copy)", position = count))
    }

    suspend fun reorderItems(items: List<ItemEntity>) {
        items.forEachIndexed { index, item ->
            itemDao.update(item.copy(position = index))
        }
    }

    suspend fun addHistoryEntry(entry: HistoryEntity) = historyDao.insert(entry)

    suspend fun deleteHistoryEntry(entry: HistoryEntity) = historyDao.delete(entry)

    suspend fun clearHistory() = historyDao.clearAll()

    suspend fun clearAllData() {
        wheelDao.deleteAll()
        historyDao.clearAll()
    }
}
