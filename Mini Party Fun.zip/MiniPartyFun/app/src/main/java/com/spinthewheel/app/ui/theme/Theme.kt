package com.spinthewheel.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Composable
fun SpinTheWheelTheme(
    accentColor: Color = AccentBlue,
    darkMode: Boolean = true,
    content: @Composable () -> Unit
) {
    val backgroundColor = if (darkMode) OneUiBackground else OneUiBackgroundLight

    val colorScheme = if (darkMode) {
        darkColorScheme(
            primary = accentColor,
            onPrimary = Color.White,
            secondary = accentColor,
            background = OneUiBackground,
            onBackground = OneUiTextPrimary,
            surface = OneUiSurface,
            onSurface = OneUiTextPrimary,
            surfaceVariant = OneUiSurfaceAlt,
            onSurfaceVariant = OneUiTextSecondary,
            outline = OneUiOutline,
            error = Color(0xFFFF5449)
        )
    } else {
        lightColorScheme(
            primary = accentColor,
            onPrimary = Color.White,
            secondary = accentColor,
            background = OneUiBackgroundLight,
            onBackground = OneUiTextPrimaryLight,
            surface = OneUiSurfaceLight,
            onSurface = OneUiTextPrimaryLight,
            surfaceVariant = OneUiSurfaceAltLight,
            onSurfaceVariant = OneUiTextSecondaryLight,
            outline = Color(0xFFD5D8E2),
            error = Color(0xFFD32F2F)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        val activity = view.context as? android.app.Activity
        activity?.window?.let { window ->
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = backgroundColor.toArgb()
            window.navigationBarColor = backgroundColor.toArgb()
            WindowCompat.getInsetsController(window, view.rootView).apply {
                isAppearanceLightStatusBars = !darkMode
                isAppearanceLightNavigationBars = !darkMode
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = OneUiTypography,
        content = content
    )
}
