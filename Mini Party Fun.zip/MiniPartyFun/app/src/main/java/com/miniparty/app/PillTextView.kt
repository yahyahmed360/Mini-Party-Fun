package com.miniparty.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.spinthewheel.app.R

/**
 * Pill button from Uiverse.io (by KhelVers), drawn natively:
 *   color #0011ff, background #f8f8fd, fully rounded, 6dp border #8b93f8,
 *   8dp hard shadow #1f35ff. On press the face drops by the shadow depth,
 *   the shadow disappears and the border darkens to #646fff.
 *
 * Use it like a TextView: set text, size and click listeners as usual.
 * Optional attrs: app:pillDepth (shadow depth) and app:pillBorder (border width).
 */
class PillTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : AppCompatTextView(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density
    private val depth: Float
    private val borderWidth: Float

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SHADOW; style = Paint.Style.FILL }
    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = FACE; style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.PillTextView)
        depth = a.getDimension(R.styleable.PillTextView_pillDepth, 8f * density)
        borderWidth = a.getDimension(R.styleable.PillTextView_pillBorder, 6f * density)
        a.recycle()
        borderPaint.strokeWidth = borderWidth
        // Text must be centred on the face, not on the face + shadow.
        setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom + depth.toInt())
        isClickable = true
        isFocusable = true
        gravity = android.view.Gravity.CENTER
        setTextColor(TEXT)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        invalidate()
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.5f
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val faceH = h - depth
        if (faceH <= 0f) {
            super.onDraw(canvas)
            return
        }
        val radius = faceH / 2f
        val dy = if (isPressed) depth else 0f

        if (!isPressed) {
            rect.set(0f, depth, w, h)
            canvas.drawRoundRect(rect, radius, radius, shadowPaint)
        }

        rect.set(0f, dy, w, dy + faceH)
        canvas.drawRoundRect(rect, radius, radius, facePaint)

        borderPaint.color = if (isPressed) BORDER_PRESSED else BORDER
        val inset = borderWidth / 2f
        rect.set(inset, dy + inset, w - inset, dy + faceH - inset)
        val innerRadius = (faceH - borderWidth) / 2f
        canvas.drawRoundRect(rect, innerRadius, innerRadius, borderPaint)

        canvas.save()
        canvas.translate(0f, dy)
        super.onDraw(canvas)
        canvas.restore()
    }

    companion object {
        private const val FACE = 0xFFF8F8FD.toInt()
        private const val BORDER = 0xFF8B93F8.toInt()
        private const val BORDER_PRESSED = 0xFF646FFF.toInt()
        private const val SHADOW = 0xFF1F35FF.toInt()
        private const val TEXT = 0xFF0011FF.toInt()
    }
}
