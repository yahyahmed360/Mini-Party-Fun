package com.miniparty.fun

import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val diceFragment = DiceFragment()
    private val coinFragment = CoinFragment()
    private val bottleFragment = BottleFragment()
    private val settingsFragment = SettingsFragment()

    private lateinit var navItems: Map<Int, LinearLayout>
    private var currentTab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container, settingsFragment, "settings").hide(settingsFragment)
                .add(R.id.fragment_container, bottleFragment, "bottle").hide(bottleFragment)
                .add(R.id.fragment_container, coinFragment, "coin").hide(coinFragment)
                .add(R.id.fragment_container, diceFragment, "dice")
                .commit()
        }

        val navDice = findViewById<LinearLayout>(R.id.nav_item_dice)
        val navCoin = findViewById<LinearLayout>(R.id.nav_item_coin)
        val navBottle = findViewById<LinearLayout>(R.id.nav_item_bottle)
        val navSettings = findViewById<LinearLayout>(R.id.nav_item_settings)

        navItems = mapOf(
            0 to navDice,
            1 to navCoin,
            2 to navBottle,
            3 to navSettings
        )

        navDice.setOnClickListener { selectTab(0) }
        navCoin.setOnClickListener { selectTab(1) }
        navBottle.setOnClickListener { selectTab(2) }
        navSettings.setOnClickListener { selectTab(3) }

        highlightTab(0)
    }

    private fun selectTab(index: Int) {
        if (index == currentTab) return
        val transaction = supportFragmentManager.beginTransaction()
        val fragments = listOf(diceFragment, coinFragment, bottleFragment, settingsFragment)
        fragments.forEachIndexed { i, fragment ->
            if (i == index) transaction.show(fragment) else transaction.hide(fragment)
        }
        transaction.commit()
        currentTab = index
        highlightTab(index)
    }

    private fun highlightTab(index: Int) {
        navItems.forEach { (i, view) ->
            view.setBackgroundResource(if (i == index) R.drawable.bg_nav_item_selected else 0)
        }
    }
}
