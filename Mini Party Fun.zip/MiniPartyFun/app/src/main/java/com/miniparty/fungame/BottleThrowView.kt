package com.miniparty.fungame

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import kotlin.math.sin
import kotlin.random.Random

class BottleThrowView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onThrowFinished: ((Boolean) -> Unit)? = null

    private val bottleBitmap: Bitmap by lazy {
        BitmapFactory.decodeResource(resources, R.drawable.img_bottle)
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#42A5F5")
        alpha = 190
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#40000000")
    }

    private var rotationDeg = 0f
    private var liftFraction = 0f // 0 = resting on the "table", 1 = peak of the throw
    private var scaleFactor = 1f
    private var waterPhase = 0f
    private var throwing = false

    private val waterAnimator = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 2200
        repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener {
            waterPhase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        waterAnimator.start()
    }

    fun throwBottle() {
        if (throwing) return
        throwing = true
        vibrate()

        val landsUpright = Random.nextInt(100) < 45 // Sometimes lands correctly, sometimes falls.
        val fullSpins = 2 + Random.nextInt(3)
        val finalRotation = if (landsUpright) 360f * fullSpins else 360f * fullSpins + if (Random.nextBoolean()) 90f else -90f

        val upAnimator = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = 1100
            interpolator = DecelerateInterpolator(1f)
            addUpdateListener {
                liftFraction = it.animatedValue as Float
                invalidate()
            }
        }
        val rotateAnimator = ValueAnimator.ofFloat(0f, finalRotation).apply {
            duration = 1100
            interpolator = AccelerateInterpolator(1.1f)
            addUpdateListener {
                rotationDeg = it.animatedValue as Float
                invalidate()
            }
        }

        val set = AnimatorSet()
        set.playTogether(upAnimator, rotateAnimator)
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                bounceSettle(landsUpright)
            }
        })
        set.start()
    }

    private fun bounceSettle(landsUpright: Boolean) {
        val bounce = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                scaleFactor = 1f - 0.12f * (it.animatedValue as Float)
                invalidate()
            }
        }
        bounce.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                scaleFactor = 1f
                throwing = false
                invalidate()
                onThrowFinished?.invoke(landsUpright)
            }
        })
        bounce.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val aspect = bottleBitmap.width.toFloat() / bottleBitmap.height.toFloat()
        val bottleH = h * 0.62f
        val bottleW = bottleH * aspect
        val cx = w / 2f
        val restY = h * 0.72f
        val liftPx = h * 0.28f * liftFraction
        val cy = restY - liftPx

        // Ground shadow, shrinks while the bottle is in the air.
        val shadowScale = 1f - 0.6f * liftFraction
        val shadowRect = RectF(
            cx - (bottleW * 0.42f) * shadowScale,
            restY + bottleH * 0.06f - (bottleH * 0.06f * shadowScale),
            cx + (bottleW * 0.42f) * shadowScale,
            restY + bottleH * 0.14f
        )
        canvas.drawOval(shadowRect, shadowPaint)

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(rotationDeg)
        canvas.scale(scaleFactor, scaleFactor)
        val left = -bottleW / 2f
        val top = -bottleH / 2f
        val destRect = RectF(left, top, left + bottleW, top + bottleH)
        canvas.drawBitmap(bottleBitmap, null, destRect, bitmapPaint)

        // Animated water glint over the lower body.
        canvas.save()
        val bodyRect = RectF(
            destRect.left + destRect.width() * 0.22f,
            destRect.top + destRect.height() * 0.64f,
            destRect.right - destRect.width() * 0.20f,
            destRect.bottom - destRect.height() * 0.06f
        )
        canvas.clipRect(bodyRect)
        val wavePath = Path()
        wavePath.moveTo(bodyRect.left, bodyRect.bottom)
        val waterTop = bodyRect.top + bodyRect.height() * 0.22f
        wavePath.lineTo(bodyRect.left, waterTop)
        val steps = 20
        for (s in 0..steps) {
            val fx = bodyRect.left + (bodyRect.width() * s / steps)
            val wave = sin(waterPhase + s * 0.7f) * 7f
            wavePath.lineTo(fx, waterTop + wave)
        }
        wavePath.lineTo(bodyRect.right, bodyRect.bottom)
        wavePath.close()
        canvas.drawPath(wavePath, waterPaint)
        canvas.restore()

        canvas.restore()
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(40)
                }
            }
        } catch (e: Exception) {
            // No vibrator - ignore.
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        waterAnimator.cancel()
    }
}
