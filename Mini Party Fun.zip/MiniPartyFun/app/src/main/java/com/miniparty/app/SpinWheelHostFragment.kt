package com.miniparty.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.fragment.app.Fragment
import com.spinthewheel.app.SpinTheWheelApp
import com.spinthewheel.app.data.datastore.AppSettings
import com.spinthewheel.app.navigation.SpinTheWheelNavGraph
import com.spinthewheel.app.ui.theme.AccentBlue
import com.spinthewheel.app.ui.theme.AccentOptions
import com.spinthewheel.app.ui.theme.SpinTheWheelTheme

/**
 * Hosts the complete, unmodified Spin the Wheel Compose app inside the combined
 * app's "Spin the Wheel" tab. This is the same composable entry point that Spin
 * the Wheel's own standalone MainActivity used to call directly - only the host
 * (a Fragment's ComposeView instead of an Activity's setContent) has changed, so
 * every screen, animation, and its own independent light/dark theme keep working
 * exactly as before.
 */
class SpinWheelHostFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                val appContainer = (requireActivity().application as SpinTheWheelApp).container
                val settings by appContainer.settingsDataStore.settingsFlow.collectAsState(
                    initial = AppSettings()
                )
                val accentColor: Color = AccentOptions.firstOrNull { it.first == settings.accentColorName }
                    ?.second ?: AccentBlue

                SpinTheWheelTheme(accentColor = accentColor, darkMode = settings.darkMode) {
                    SpinTheWheelNavGraph(container = appContainer)
                }
            }
        }
    }
}
