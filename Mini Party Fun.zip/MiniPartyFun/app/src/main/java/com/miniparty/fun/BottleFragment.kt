package com.miniparty.fun

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import kotlin.random.Random

class BottleFragment : Fragment(R.layout.fragment_bottle) {

    private val min = 2
    private val max = 25
    private val tapStep = 1
    private val holdStep = 7

    private lateinit var wheel: BottleWheelView
    private lateinit var tvCount: TextView

    private val presetColors: List<Pair<String, Int>> by lazy {
        listOf(
            "Light Blue" to ContextCompat.getColor(requireContext(), R.color.light_blue),
            "Light Green" to ContextCompat.getColor(requireContext(), R.color.light_green),
            "Dark Blue" to ContextCompat.getColor(requireContext(), R.color.dark_blue),
            "Dark Green" to ContextCompat.getColor(requireContext(), R.color.dark_green),
            "Purple" to ContextCompat.getColor(requireContext(), R.color.purple),
            "Red" to ContextCompat.getColor(requireContext(), R.color.red),
            "Pink" to ContextCompat.getColor(requireContext(), R.color.pink),
            "Orange" to ContextCompat.getColor(requireContext(), R.color.orange),
            "Yellow" to ContextCompat.getColor(requireContext(), R.color.yellow),
            "Navy Blue" to ContextCompat.getColor(requireContext(), R.color.navy_blue)
        )
    }

    private fun randomFlapColor(): Int {
        val palette = listOf(
            R.color.light_blue, R.color.light_green, R.color.dark_blue, R.color.dark_green,
            R.color.purple, R.color.red, R.color.pink, R.color.orange, R.color.yellow, R.color.navy_blue
        )
        return ContextCompat.getColor(requireContext(), palette[Random.nextInt(palette.size)])
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        wheel = view.findViewById(R.id.wheel_view)
        tvCount = view.findViewById(R.id.tv_count)
        val btnMinus = view.findViewById<View>(R.id.btn_minus)
        val btnPlus = view.findViewById<View>(R.id.btn_plus)
        val btnAction = view.findViewById<View>(R.id.btn_action)

        fun refreshCount() {
            tvCount.text = wheel.flaps.size.toString()
        }
        refreshCount()

        fun setCount(newCount: Int) {
            val target = newCount.coerceIn(min, max)
            val current = wheel.flaps
            if (target > current.size) {
                while (current.size < target) {
                    current.add(Flap("New", randomFlapColor(), "☕"))
                }
            } else if (target < current.size) {
                while (current.size > target) {
                    current.removeAt(current.size - 1)
                }
            }
            wheel.flaps = current
            refreshCount()
        }

        btnMinus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = { setCount(wheel.flaps.size - tapStep) },
            onLongPress = { setCount(wheel.flaps.size - holdStep) }
        ))

        btnPlus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = { setCount(wheel.flaps.size + tapStep) },
            onLongPress = { setCount(wheel.flaps.size + holdStep) }
        ))

        btnAction.setOnClickListener {
            wheel.startSpin()
        }

        wheel.onFlapTap = { index -> showEditDialog(index) }
        wheel.onFlapLongPress = { index -> showActionDialog(index) }
        wheel.onBottleLongPress = { showResetDialog() }
    }

    private fun showEditDialog(index: Int) {
        if (index < 0 || index >= wheel.flaps.size) return
        val flap = wheel.flaps[index]
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_flap_edit, null)
        val etName = dialogView.findViewById<EditText>(R.id.et_name)
        val etHex = dialogView.findViewById<EditText>(R.id.et_hex)
        val etEmoji = dialogView.findViewById<EditText>(R.id.et_emoji)
        val colorGrid = dialogView.findViewById<GridLayout>(R.id.color_grid)

        etName.setText(flap.name)
        etEmoji.setText(flap.emoji)

        var selectedColor = flap.color
        val swatchViews = mutableListOf<View>()

        fun refreshSwatchBorders() {
            swatchViews.forEachIndexed { i, v ->
                v.background = buildSwatchDrawable(presetColors[i].second, presetColors[i].second == selectedColor)
            }
        }

        val sizePx = (36 * resources.displayMetrics.density).toInt()
        val marginPx = (6 * resources.displayMetrics.density).toInt()
        for ((name, color) in presetColors) {
            val swatch = View(requireContext())
            val params = GridLayout.LayoutParams()
            params.width = sizePx
            params.height = sizePx
            params.setMargins(marginPx, marginPx, marginPx, marginPx)
            swatch.layoutParams = params
            swatch.contentDescription = name
            swatch.setOnClickListener {
                selectedColor = color
                etHex.text?.clear()
                refreshSwatchBorders()
            }
            colorGrid.addView(swatch)
            swatchViews.add(swatch)
        }
        refreshSwatchBorders()

        AlertDialog.Builder(requireContext())
            .setTitle(flap.name)
            .setView(dialogView)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = etName.text?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: flap.name
                val hexInput = etHex.text?.toString()?.trim()
                val finalColor = if (!hexInput.isNullOrEmpty()) {
                    try {
                        val normalizedHex = if (hexInput.startsWith("#")) hexInput else "#$hexInput"
                        Color.parseColor(normalizedHex)
                    } catch (e: IllegalArgumentException) {
                        Toast.makeText(requireContext(), "Invalid hex color, keeping previous color", Toast.LENGTH_SHORT).show()
                        selectedColor
                    }
                } else {
                    selectedColor
                }
                val newEmoji = etEmoji.text?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: flap.emoji
                wheel.flaps[index] = Flap(newName, finalColor, newEmoji)
                wheel.flaps = wheel.flaps
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun buildSwatchDrawable(color: Int, selected: Boolean): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.OVAL
        drawable.setColor(color)
        if (selected) {
            drawable.setStroke((3 * resources.displayMetrics.density).toInt(), Color.parseColor("#FFD700"))
        }
        return drawable
    }

    private fun showActionDialog(index: Int) {
        if (index < 0 || index >= wheel.flaps.size) return
        val flap = wheel.flaps[index]
        AlertDialog.Builder(requireContext())
            .setTitle(flap.name)
            .setItems(arrayOf(getString(R.string.delete), getString(R.string.save), getString(R.string.cancel))) { dialog, which ->
                when (which) {
                    0 -> {
                        if (wheel.flaps.size > min) {
                            wheel.flaps.removeAt(index)
                            wheel.flaps = wheel.flaps
                            tvCount.text = wheel.flaps.size.toString()
                        } else {
                            Toast.makeText(requireContext(), "Minimum of $min flaps required", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> { /* Save - keep flap unchanged, just close */ }
                    2 -> { /* Cancel */ }
                }
                dialog.dismiss()
            }
            .show()
    }

    private fun showResetDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.reset))
            .setMessage("Reset the Bottle Flip wheel to its default state?")
            .setPositiveButton(R.string.reset) { _, _ ->
                AlertDialog.Builder(requireContext())
                    .setTitle(R.string.are_you_sure)
                    .setMessage("This will remove all your custom flaps.")
                    .setPositiveButton(R.string.reset) { _, _ ->
                        wheel.resetToDefault()
                        tvCount.text = wheel.flaps.size.toString()
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
