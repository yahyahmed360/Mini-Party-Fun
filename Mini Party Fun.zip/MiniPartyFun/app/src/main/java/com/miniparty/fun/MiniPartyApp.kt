package com.miniparty.fun

import android.app.Application

class MiniPartyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.applyThemeMode(Prefs.getThemeMode(this))
    }
}
