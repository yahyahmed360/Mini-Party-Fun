package com.miniparty.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Fixed dark colour scheme for the combined app's own shell (tab switcher, info box,
 * Settings tab). Deliberately NOT tied to Spin the Wheel's or More's own theme settings.
 */
private val ShellColors = darkColorScheme(
    primary = Color(0xFF4C9AFF),
    onPrimary = Color.Black,
    background = Color(0xFF000000),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF1C1C1E),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF2A2A2D),
    onSurfaceVariant = Color(0xFF9A9AA2)
)

@Composable
fun ShellTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ShellColors, content = content)
}
