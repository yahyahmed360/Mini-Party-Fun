package com.miniparty.fungame

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.view.View

/**
 * Attaches tap / 3-second-long-press behaviour to a view.
 * Quick tap -> onTap()
 * Held for 3 seconds -> vibrates once and calls onLongPress()
 */
class HoldButtonHelper(
    private val context: Context,
    private val onTap: () -> Unit,
    private val onLongPress: () -> Unit
) : View.OnTouchListener {

    companion object {
        private const val LONG_PRESS_MS = 3000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var longPressFired = false
    private val longPressRunnable = Runnable {
        longPressFired = true
        vibrate()
        onLongPress()
    }

    private fun vibrate() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(60)
                }
            }
        } catch (e: Exception) {
            // No vibrator available - ignore.
        }
    }

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                longPressFired = false
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS)
                v.alpha = 0.75f
            }
            MotionEvent.ACTION_UP -> {
                v.alpha = 1f
                handler.removeCallbacks(longPressRunnable)
                if (!longPressFired) {
                    onTap()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                v.alpha = 1f
                handler.removeCallbacks(longPressRunnable)
            }
        }
        return true
    }
}
