package com.miniparty.app

import android.content.Context

/**
 * Stores the combined app's own "Default Tab" preference (Settings tab).
 * This is completely separate from Spin the Wheel's settings (DataStore)
 * and from Mini Party Fun's own theme Prefs - it only controls which of
 * the two main tabs (Spin the Wheel / More) opens when the app launches.
 */
object CombinedPrefs {
    private const val PREF_NAME = "mini_party_fun_combined_prefs"
    private const val KEY_DEFAULT_TAB = "default_tab"

    const val TAB_SPIN_WHEEL = 0
    const val TAB_MORE = 1

    fun getDefaultTab(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_DEFAULT_TAB, TAB_SPIN_WHEEL)
    }

    fun setDefaultTab(context: Context, tab: Int) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_DEFAULT_TAB, tab).apply()
    }

    /** Whether the info box of a top-level tab (0 = Spin the Wheel, 1 = More, 2 = Settings) is collapsed. */
    fun isInfoCollapsed(context: Context, tab: Int): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean("info_collapsed_$tab", false)
    }

    fun setInfoCollapsed(context: Context, tab: Int, collapsed: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean("info_collapsed_$tab", collapsed).apply()
    }
}
