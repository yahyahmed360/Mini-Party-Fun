package com.miniparty.fungame

import com.spinthewheel.app.R

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class DiceFragment : Fragment(R.layout.fragment_dice) {

    private var count = 6
    private val min = 2
    private val max = 40
    private val tapStep = 1
    private val holdStep = 10

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvCount = view.findViewById<TextView>(R.id.tv_count)
        val tvResult = view.findViewById<TextView>(R.id.tv_result)
        val ivDice = view.findViewById<ImageView>(R.id.iv_dice)
        val btnMinus = view.findViewById<View>(R.id.btn_minus)
        val btnPlus = view.findViewById<View>(R.id.btn_plus)
        val btnAction = view.findViewById<View>(R.id.btn_action)

        fun refresh() {
            tvCount.text = count.toString()
        }
        refresh()

        btnMinus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = {
                count = (count - tapStep).coerceAtLeast(min)
                refresh()
            },
            onLongPress = {
                count = (count - holdStep).coerceAtLeast(min)
                refresh()
            }
        ))

        btnPlus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = {
                count = (count + tapStep).coerceAtMost(max)
                refresh()
            },
            onLongPress = {
                count = (count + holdStep).coerceAtMost(max)
                refresh()
            }
        ))

        btnAction.setOnClickListener {
            val outcome = Random.nextInt(1, count + 1)
            ivDice.animate().cancel()
            ivDice.rotation = 0f
            ivDice.animate()
                .rotationBy(360f + Random.nextInt(0, 4) * 90f)
                .setDuration(550)
                .withEndAction { tvResult.text = outcome.toString() }
                .start()
        }
    }
}
