package com.miniparty.fungame

import android.app.Application

class MiniPartyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.applyThemeMode(Prefs.getThemeMode(this))
    }
}
