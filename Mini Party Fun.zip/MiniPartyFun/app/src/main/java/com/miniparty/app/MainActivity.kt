package com.miniparty.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.miniparty.app.ui.ShellHeader
import com.spinthewheel.app.R

/**
 * Combined app entry point. Shows a liquid tab switcher plus a per-tab info box directly
 * below the status bar with three tabs - Spin the Wheel, More, and Settings - and swaps
 * their content via fragment show/hide (nothing is ever recreated when switching tabs).
 *
 * Spin the Wheel and Mini Party Fun (More) each keep running exactly as they did
 * standalone, including their own independent theme systems. This Activity itself
 * only owns the header (tab switcher + info box) and the "Default Tab" setting.
 */
class MainActivity : AppCompatActivity() {

    private val selectedTab = mutableIntStateOf(CombinedPrefs.TAB_SPIN_WHEEL)

    private lateinit var spinWheelFragment: SpinWheelHostFragment
    private lateinit var moreFragment: MorePartyFunFragment
    private lateinit var settingsFragment: CombinedSettingsFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Keep the header below the status bar regardless of whether the currently
        // shown tab draws edge-to-edge (Spin the Wheel's own theme does).
        val header = findViewById<ComposeView>(R.id.shell_header)
        val headerInitialPaddingTop = header.paddingTop
        ViewCompat.setOnApplyWindowInsetsListener(header) { view, insets ->
            val statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            view.updatePadding(top = headerInitialPaddingTop + statusBarInsets.top)
            insets
        }

        val restored = savedInstanceState != null
        val startTab = savedInstanceState?.getInt(KEY_TAB) ?: CombinedPrefs.getDefaultTab(this)

        // After a configuration-driven recreation the fragment manager already holds the
        // previously added fragments - reuse them instead of creating orphans.
        spinWheelFragment = (supportFragmentManager.findFragmentByTag("spin_wheel") as? SpinWheelHostFragment)
            ?: SpinWheelHostFragment()
        moreFragment = (supportFragmentManager.findFragmentByTag("more") as? MorePartyFunFragment)
            ?: MorePartyFunFragment()
        settingsFragment = (supportFragmentManager.findFragmentByTag("settings") as? CombinedSettingsFragment)
            ?: CombinedSettingsFragment()

        if (!restored) {
            val transaction = supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container, settingsFragment, "settings").hide(settingsFragment)
                .add(R.id.fragment_container, moreFragment, "more")
                .add(R.id.fragment_container, spinWheelFragment, "spin_wheel")

            if (startTab == CombinedPrefs.TAB_MORE) {
                transaction.hide(spinWheelFragment)
            } else {
                transaction.hide(moreFragment)
            }
            transaction.commit()
        }
        selectedTab.intValue = startTab

        header.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        header.setContent {
            ShellHeader(
                selectedIndex = selectedTab.intValue,
                onSelect = { selectTab(it) },
                isCollapsed = { CombinedPrefs.isInfoCollapsed(this, it) },
                onCollapsedChange = { tab, collapsed -> CombinedPrefs.setInfoCollapsed(this, tab, collapsed) }
            )
        }

        if (startTab != CombinedPrefs.TAB_SPIN_WHEEL) {
            restoreCombinedStatusBar()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, selectedTab.intValue)
    }

    private fun selectTab(index: Int) {
        if (index == selectedTab.intValue) return
        val transaction = supportFragmentManager.beginTransaction()
        val fragments = listOf(spinWheelFragment, moreFragment, settingsFragment)
        fragments.forEachIndexed { i, fragment ->
            if (i == index) transaction.show(fragment) else transaction.hide(fragment)
        }
        transaction.commit()
        selectedTab.intValue = index

        // Spin the Wheel's own theme sets the window's status/navigation bar color
        // and switches to edge-to-edge the first time it is shown, and nothing ever
        // resets that when you leave the tab (its Compose content is only hidden,
        // not disposed, so its one-time color effect never runs again). Restore the
        // combined app's own bar color whenever a non-Spin-the-Wheel tab is active.
        if (index != CombinedPrefs.TAB_SPIN_WHEEL) {
            restoreCombinedStatusBar()
        }
    }

    private fun restoreCombinedStatusBar() {
        val barColor = ContextCompat.getColor(this, R.color.combined_bar_bg)
        window.statusBarColor = barColor
        window.navigationBarColor = barColor
    }

    private companion object {
        const val KEY_TAB = "selected_tab"
    }
}
