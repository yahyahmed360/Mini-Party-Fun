package com.miniparty.fungame

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment

class BottleThrowFragment : Fragment(R.layout.fragment_bottle_throw) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val throwView = view.findViewById<BottleThrowView>(R.id.throw_view)
        val tvResult = view.findViewById<TextView>(R.id.tv_throw_result)
        val btnAction = view.findViewById<View>(R.id.btn_action)

        throwView.onThrowFinished = { landedUpright ->
            tvResult.text = if (landedUpright) {
                getString(R.string.result_landed)
            } else {
                getString(R.string.result_fell)
            }
        }

        btnAction.setOnClickListener {
            tvResult.text = "..."
            throwView.throwBottle()
        }
    }
}
