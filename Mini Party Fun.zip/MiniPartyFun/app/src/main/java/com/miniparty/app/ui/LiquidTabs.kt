package com.miniparty.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.min

/**
 * Liquid tab switcher (recreated from a Uiverse.io "liquid-group"):
 * black rounded container, 6dp gap, #222 slider with inset highlight, dim/bright labels,
 * 0.97 press scale and a spring-driven slider with a small liquid stretch while it travels.
 */
@Composable
fun LiquidTabs(
    tabs: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val gap = 6.dp
    val tabHeight = 44.dp
    val outerShape = RoundedCornerShape(16.dp)
    val sliderShape = RoundedCornerShape(12.dp)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .clip(outerShape)
            .background(Color.Black)
            .border(1.dp, Color(0xFF1A1A1A), outerShape)
            .padding(gap)
    ) {
        val tabWidth = maxWidth / tabs.size
        val tabWidthPx = with(LocalDensity.current) { tabWidth.toPx() }

        val offset = remember { Animatable(0f) }
        var placed by remember { mutableStateOf(false) }
        LaunchedEffect(selectedIndex, tabWidthPx) {
            val target = selectedIndex * tabWidthPx
            if (!placed) {
                offset.snapTo(target)
                placed = true
            } else {
                offset.animateTo(target, spring(dampingRatio = 0.62f, stiffness = 260f))
            }
        }

        // Liquid slider
        Box(
            modifier = Modifier
                .size(tabWidth, tabHeight)
                .graphicsLayer {
                    translationX = offset.value
                    val travel = min(abs(selectedIndex * tabWidthPx - offset.value) / tabWidthPx, 1f)
                    scaleX = 1f + 0.14f * travel
                    scaleY = 1f - 0.05f * travel
                }
                .clip(sliderShape)
                .background(Color(0xFF222222))
                .border(
                    1.dp,
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.10f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.60f)
                        )
                    ),
                    sliderShape
                )
        )

        // Labels
        Row(Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { index, label ->
                val interaction = remember { MutableInteractionSource() }
                val pressed by interaction.collectIsPressedAsState()
                val scale by animateFloatAsState(
                    targetValue = if (pressed) 0.97f else 1f,
                    animationSpec = tween(200),
                    label = "tabPress"
                )
                val textColor by animateColorAsState(
                    targetValue = if (index == selectedIndex) Color.White else Color(0xFF555555),
                    animationSpec = tween(350),
                    label = "tabColor"
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(tabHeight)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .clickable(
                            interactionSource = interaction,
                            indication = null,
                            role = Role.Tab,
                            onClick = { onSelect(index) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = textColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.5.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
