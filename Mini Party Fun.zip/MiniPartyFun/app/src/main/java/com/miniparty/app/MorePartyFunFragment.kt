package com.miniparty.app

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.miniparty.fungame.BottleFragment
import com.miniparty.fungame.BottleThrowFragment
import com.miniparty.fungame.CoinFragment
import com.miniparty.fungame.DiceFragment
import com.miniparty.fungame.SettingsFragment
import com.spinthewheel.app.R

/**
 * Hosts the complete, unmodified Mini Party Fun app (Dice, Coin, Bottle Flip,
 * Bottle Throw, and its own internal Settings tab with its own independent
 * light/dark/system theme) inside the combined app's "More" tab.
 *
 * This mirrors what used to be Mini Party Fun's standalone MainActivity, just
 * running inside a child Fragment instead of its own Activity, so switching
 * top-level tabs never restarts this content.
 */
class MorePartyFunFragment : Fragment(R.layout.fragment_more_root) {

    private val diceFragment = DiceFragment()
    private val coinFragment = CoinFragment()
    private val bottleFragment = BottleFragment()
    private val bottleThrowFragment = BottleThrowFragment()
    private val settingsFragment = SettingsFragment()

    private lateinit var navItems: Map<Int, LinearLayout>
    private var currentTab = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (childFragmentManager.findFragmentByTag("dice") == null) {
            childFragmentManager.beginTransaction()
                .add(R.id.fragment_container, settingsFragment, "settings").hide(settingsFragment)
                .add(R.id.fragment_container, bottleThrowFragment, "bottle_throw").hide(bottleThrowFragment)
                .add(R.id.fragment_container, bottleFragment, "bottle").hide(bottleFragment)
                .add(R.id.fragment_container, coinFragment, "coin").hide(coinFragment)
                .add(R.id.fragment_container, diceFragment, "dice")
                .commit()
        }

        val navDice = view.findViewById<LinearLayout>(R.id.nav_item_dice)
        val navCoin = view.findViewById<LinearLayout>(R.id.nav_item_coin)
        val navBottle = view.findViewById<LinearLayout>(R.id.nav_item_bottle)
        val navBottleThrow = view.findViewById<LinearLayout>(R.id.nav_item_bottle_throw)
        val navSettings = view.findViewById<LinearLayout>(R.id.nav_item_settings)

        navItems = mapOf(
            0 to navDice,
            1 to navCoin,
            2 to navBottle,
            3 to navBottleThrow,
            4 to navSettings
        )

        navDice.setOnClickListener { selectTab(0) }
        navCoin.setOnClickListener { selectTab(1) }
        navBottle.setOnClickListener { selectTab(2) }
        navBottleThrow.setOnClickListener { selectTab(3) }
        navSettings.setOnClickListener { selectTab(4) }

        highlightTab(currentTab)
    }

    private fun selectTab(index: Int) {
        if (index == currentTab) return
        val transaction = childFragmentManager.beginTransaction()
        val fragments = listOf(diceFragment, coinFragment, bottleFragment, bottleThrowFragment, settingsFragment)
        fragments.forEachIndexed { i, fragment ->
            if (i == index) transaction.show(fragment) else transaction.hide(fragment)
        }
        transaction.commit()
        currentTab = index
        highlightTab(index)
    }

    private fun highlightTab(index: Int) {
        navItems.forEach { (i, view) ->
            val selected = i == index
            view.setBackgroundResource(if (selected) R.drawable.bg_nav_item_selected else 0)
            // Liquid-tab look: bright label on the selected slider, dim labels elsewhere.
            for (c in 0 until view.childCount) {
                (view.getChildAt(c) as? android.widget.TextView)?.let { tv ->
                    if (tv.id == View.NO_ID) {
                        tv.setTextColor(if (selected) 0xFFFFFFFF.toInt() else 0xFF777777.toInt())
                    }
                    tv.animate().alpha(if (selected) 1f else 0.7f).setDuration(200).start()
                }
            }
            view.animate().scaleX(if (selected) 1f else 0.97f).scaleY(if (selected) 1f else 0.97f)
                .setDuration(200).start()
        }
    }
}
