package com.miniparty.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.spinthewheel.app.R

/**
 * Header shown above every tab: the liquid tab switcher plus a collapsible
 * info box that explains the tab you are currently on.
 */
@Composable
fun ShellHeader(
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    isCollapsed: (Int) -> Boolean,
    onCollapsedChange: (Int, Boolean) -> Unit
) {
    ShellTheme {
        val collapsed = remember {
            mutableStateListOf<Boolean>().apply { for (i in 0 until 3) add(isCollapsed(i)) }
        }
        val labels = listOf(
            stringResource(R.string.top_tab_spin_wheel),
            stringResource(R.string.top_tab_more),
            stringResource(R.string.top_tab_settings)
        )
        val titles = listOf(
            stringResource(R.string.info_title_spin_wheel),
            stringResource(R.string.info_title_more),
            stringResource(R.string.info_title_settings)
        )
        val bodies = listOf(
            stringResource(R.string.info_body_spin_wheel),
            stringResource(R.string.info_body_more),
            stringResource(R.string.info_body_settings)
        )

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            LiquidTabs(
                tabs = labels,
                selectedIndex = selectedIndex,
                onSelect = onSelect
            )
            Spacer(Modifier.height(12.dp))
            AnimatedContent(
                targetState = selectedIndex,
                transitionSpec = {
                    (fadeIn(tween(250)) togetherWith fadeOut(tween(150))).using(SizeTransform(clip = false))
                },
                label = "infoBox"
            ) { tab ->
                InfoBox(
                    title = titles[tab],
                    body = bodies[tab],
                    collapsed = collapsed[tab],
                    onToggle = {
                        val newValue = !collapsed[tab]
                        collapsed[tab] = newValue
                        onCollapsedChange(tab, newValue)
                    }
                )
            }
        }
    }
}

/** Tinted info card (primary at 10% alpha, 24dp corners). Tap the header row to hide / show the text. */
@Composable
fun InfoBox(
    title: String,
    body: String,
    collapsed: Boolean,
    onToggle: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = cs.primary.copy(alpha = 0.10f)
    ) {
        Column(
            Modifier
                .clickable(onClick = onToggle)
                .padding(horizontal = 20.dp, vertical = 14.dp)
                .animateContentSize()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    color = cs.primary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = if (collapsed) stringResource(R.string.info_show) else stringResource(R.string.info_hide),
                    color = cs.primary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            AnimatedVisibility(
                visible = !collapsed,
                enter = expandVertically(tween(200)) + fadeIn(tween(200)),
                exit = shrinkVertically(tween(200)) + fadeOut(tween(150))
            ) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = body,
                        color = cs.onSurface,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }
    }
}
