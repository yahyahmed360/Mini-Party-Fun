package com.miniparty.fungame

import com.spinthewheel.app.R

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class CoinFragment : Fragment(R.layout.fragment_coin) {

    private var count = 2
    private val min = 2
    private val max = 15
    private val tapStep = 1
    private val holdStep = 3

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvCount = view.findViewById<TextView>(R.id.tv_count)
        val tvResult = view.findViewById<TextView>(R.id.tv_result)
        val ivCoin = view.findViewById<ImageView>(R.id.iv_coin)
        val btnMinus = view.findViewById<View>(R.id.btn_minus)
        val btnPlus = view.findViewById<View>(R.id.btn_plus)
        val btnAction = view.findViewById<View>(R.id.btn_action)

        fun refresh() {
            tvCount.text = count.toString()
        }
        refresh()

        btnMinus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = {
                count = (count - tapStep).coerceAtLeast(min)
                refresh()
            },
            onLongPress = {
                count = (count - holdStep).coerceAtLeast(min)
                refresh()
            }
        ))

        btnPlus.setOnTouchListener(HoldButtonHelper(
            requireContext(),
            onTap = {
                count = (count + tapStep).coerceAtMost(max)
                refresh()
            },
            onLongPress = {
                count = (count + holdStep).coerceAtMost(max)
                refresh()
            }
        ))

        btnAction.setOnClickListener {
            val outcome = Random.nextInt(1, count + 1)
            ivCoin.animate().cancel()
            ivCoin.scaleX = 1f
            ivCoin.animate()
                .scaleX(0f)
                .setDuration(180)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        tvResult.text = outcome.toString()
                        ivCoin.animate()
                            .scaleX(1f)
                            .setDuration(180)
                            .setListener(null)
                            .start()
                    }
                })
                .start()
        }
    }
}
