package com.miniparty.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import com.miniparty.app.ui.ShellTheme
import com.spinthewheel.app.R

/**
 * The combined app's own Settings tab. This ONLY contains the "Default Tab"
 * chooser and the version label - it intentionally has no light/dark mode
 * option of its own, since Spin the Wheel and Mini Party Fun each keep their
 * own independent theme systems untouched.
 */
class CombinedSettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                ShellTheme {
                    CombinedSettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun CombinedSettingsScreen() {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var defaultTab by remember { mutableStateOf(CombinedPrefs.getDefaultTab(context)) }

    Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(20.dp))
            Image(
                painter = painterResource(R.drawable.logo_header),
                contentDescription = stringResource(R.string.app_name),
                modifier = Modifier
                    .size(72.dp)
                    .align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.app_name),
                color = cs.onBackground,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.default_tab_setting_label),
                color = cs.onBackground,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OptionCard(
                    title = stringResource(R.string.default_tab_spin_wheel_option),
                    subtitle = stringResource(R.string.default_tab_spin_wheel_hint),
                    selected = defaultTab == CombinedPrefs.TAB_SPIN_WHEEL
                ) {
                    defaultTab = CombinedPrefs.TAB_SPIN_WHEEL
                    CombinedPrefs.setDefaultTab(context, CombinedPrefs.TAB_SPIN_WHEEL)
                }
                OptionCard(
                    title = stringResource(R.string.default_tab_more_option),
                    subtitle = stringResource(R.string.default_tab_more_hint),
                    selected = defaultTab == CombinedPrefs.TAB_MORE
                ) {
                    defaultTab = CombinedPrefs.TAB_MORE
                    CombinedPrefs.setDefaultTab(context, CombinedPrefs.TAB_MORE)
                }
            }
            Spacer(Modifier.weight(1f))
            Text(
                text = stringResource(R.string.combined_version_label),
                color = cs.onSurfaceVariant,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            )
        }
    }
}

@Composable
private fun OptionCard(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    val borderColor by animateColorAsState(
        targetValue = if (selected) cs.primary else Color.Transparent,
        animationSpec = tween(250),
        label = "optionBorder"
    )
    Surface(
        shape = shape,
        color = cs.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, borderColor, shape)
            .clip(shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = cs.onSurfaceVariant, fontSize = 13.sp)
            }
            RadioButton(selected = selected, onClick = null)
        }
    }
}
