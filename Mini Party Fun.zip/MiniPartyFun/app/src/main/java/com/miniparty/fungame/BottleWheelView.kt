package com.miniparty.fungame

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class BottleWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var flaps: MutableList<Flap> = DefaultFlaps.createDefault()
        set(value) {
            field = value
            invalidate()
        }

    var onFlapTap: ((Int) -> Unit)? = null
    var onFlapLongPress: ((Int) -> Unit)? = null
    var onBottleLongPress: (() -> Unit)? = null
    var onSpinFinished: ((Int) -> Unit)? = null

    private var wheelRotation = 0f
    private var spinning = false
    private var glowIndex: Int = -1
    private var glowAlpha = 0
    private val handler = Handler(Looper.getMainLooper())

    private var waterPhase = 0f
    private val waterAnimator = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener {
            waterPhase = it.animatedValue as Float
            invalidate()
        }
    }

    private var glowAnimator: ValueAnimator? = null
    private val stopGlowRunnable = Runnable {
        glowAnimator?.cancel()
        glowIndex = -1
        invalidate()
    }

    private val slicePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.parseColor("#2B1F4A")
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 12f
        color = Color.parseColor("#FFD700")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 30f
    }
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 44f
    }
    private val bottleBitmap: Bitmap by lazy {
        BitmapFactory.decodeResource(resources, R.drawable.img_bottle)
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#42A5F5")
        alpha = 190
    }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD700")
        style = Paint.Style.FILL
    }

    init {
        waterAnimator.start()
    }

    fun startSpin() {
        if (spinning || flaps.isEmpty()) return
        spinning = true
        handler.removeCallbacks(stopGlowRunnable)
        glowAnimator?.cancel()
        glowIndex = -1

        val n = flaps.size
        val sliceAngle = 360f / n
        val winner = Random.nextInt(n)
        val requiredMod = normalize(-(winner * sliceAngle + sliceAngle / 2f))
        val currentMod = normalize(wheelRotation)
        var delta = requiredMod - currentMod
        if (delta < 0) delta += 360f
        val extraSpins = 5 + Random.nextInt(3)
        val target = wheelRotation + delta + 360f * extraSpins

        val animator = ValueAnimator.ofFloat(wheelRotation, target)
        animator.duration = 3200
        animator.interpolator = DecelerateInterpolator(2.2f)
        animator.addUpdateListener {
            wheelRotation = it.animatedValue as Float
            invalidate()
        }
        animator.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                spinning = false
                startGlow(winner)
                onSpinFinished?.invoke(winner)
            }
        })
        animator.start()
    }

    private fun startGlow(index: Int) {
        glowIndex = index
        glowAnimator = ValueAnimator.ofInt(90, 255).apply {
            duration = 450
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                glowAlpha = it.animatedValue as Int
                invalidate()
            }
            start()
        }
        handler.postDelayed(stopGlowRunnable, 10000)
    }

    fun resetToDefault() {
        handler.removeCallbacks(stopGlowRunnable)
        glowAnimator?.cancel()
        glowIndex = -1
        wheelRotation = 0f
        flaps = DefaultFlaps.createDefault()
    }

    private fun normalize(a: Float): Float {
        var x = a % 360f
        if (x < 0) x += 360f
        return x
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(w, h) / 2f - 16f
        if (radius <= 0f || flaps.isEmpty()) return

        val n = flaps.size
        val sliceAngle = 360f / n
        val oval = RectF(cx - radius, cy - radius, cx + radius, cy + radius)

        canvas.save()
        canvas.rotate(wheelRotation, cx, cy)
        for (i in 0 until n) {
            val startAngle = -90f + i * sliceAngle
            slicePaint.color = flaps[i].color
            canvas.drawArc(oval, startAngle, sliceAngle, true, slicePaint)
            canvas.drawArc(oval, startAngle, sliceAngle, true, strokePaint)

            if (i == glowIndex) {
                glowPaint.alpha = glowAlpha
                canvas.drawArc(oval, startAngle, sliceAngle, true, glowPaint)
            }

            val midAngleDeg = startAngle + sliceAngle / 2f
            val midAngleRad = Math.toRadians(midAngleDeg.toDouble())
            val labelRadius = radius * 0.62f
            val lx = (cx + labelRadius * cos(midAngleRad)).toFloat()
            val ly = (cy + labelRadius * sin(midAngleRad)).toFloat()

            canvas.save()
            canvas.translate(lx, ly)
            canvas.rotate(midAngleDeg + 90f)
            canvas.drawText(flaps[i].emoji, 0f, -6f, emojiPaint)
            canvas.drawText(flaps[i].name, 0f, 30f, textPaint)
            canvas.restore()
        }
        canvas.restore()

        drawPointer(canvas, cx, cy, radius)
        drawBottle(canvas, cx, cy, radius)
    }

    private fun drawPointer(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val path = Path()
        val topY = cy - radius - 6f
        path.moveTo(cx - 16f, topY - 22f)
        path.lineTo(cx + 16f, topY - 22f)
        path.lineTo(cx, topY + 6f)
        path.close()
        canvas.drawPath(path, pointerPaint)
    }

    private fun drawBottle(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        // Smaller bottle for the wheel, using the real bottle artwork.
        val aspect = bottleBitmap.width.toFloat() / bottleBitmap.height.toFloat()
        val bottleH = radius * 0.72f
        val bottleW = bottleH * aspect
        val bob = sin(waterPhase * 0.5f) * 4f
        val left = cx - bottleW / 2f
        val top = cy - bottleH / 2f + bob
        val destRect = RectF(left, top, left + bottleW, top + bottleH)

        canvas.drawBitmap(bottleBitmap, null, destRect, bitmapPaint)

        // Animated water glint layered over the lower body area to suggest moving liquid.
        canvas.save()
        val bodyRect = RectF(
            destRect.left + destRect.width() * 0.22f,
            destRect.top + destRect.height() * 0.64f,
            destRect.right - destRect.width() * 0.20f,
            destRect.bottom - destRect.height() * 0.06f
        )
        canvas.clipRect(bodyRect)
        val wavePath = Path()
        wavePath.moveTo(bodyRect.left, bodyRect.bottom)
        val waterTop = bodyRect.top + bodyRect.height() * 0.22f
        wavePath.lineTo(bodyRect.left, waterTop)
        val steps = 20
        for (s in 0..steps) {
            val fx = bodyRect.left + (bodyRect.width() * s / steps)
            val wave = sin(waterPhase + s * 0.7f) * 6f
            wavePath.lineTo(fx, waterTop + wave)
        }
        wavePath.lineTo(bodyRect.right, bodyRect.bottom)
        wavePath.close()
        canvas.drawPath(wavePath, waterPaint)
        canvas.restore()
    }

    // ---- Touch handling ----

    private var downTime = 0L
    private var pendingIndex = -1
    private var pendingIsBottle = false
    private var longPressFired = false
    private val longPressRunnable = Runnable {
        longPressFired = true
        vibrate()
        if (pendingIsBottle) {
            onBottleLongPress?.invoke()
        } else if (pendingIndex >= 0) {
            onFlapLongPress?.invoke(pendingIndex)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(w, h) / 2f - 16f
        val dx = event.x - cx
        val dy = event.y - cy
        val dist = sqrt(dx * dx + dy * dy)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (spinning) return true
                longPressFired = false
                val bottleRadius = radius * 0.36f
                if (dist <= bottleRadius) {
                    pendingIsBottle = true
                    pendingIndex = -1
                } else if (dist <= radius && flaps.isNotEmpty()) {
                    pendingIsBottle = false
                    val touchAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                    val origAngle = normalize(touchAngle - wheelRotation)
                    val sliceAngle = 360f / flaps.size
                    val shifted = normalize(origAngle + 90f)
                    pendingIndex = (shifted / sliceAngle).toInt().coerceIn(0, flaps.size - 1)
                } else {
                    pendingIndex = -1
                    pendingIsBottle = false
                    return true
                }
                handler.postDelayed(longPressRunnable, 3000)
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (!longPressFired) {
                    if (pendingIsBottle) {
                        // No tap action defined for the bottle itself.
                    } else if (pendingIndex >= 0) {
                        onFlapTap?.invoke(pendingIndex)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
            }
        }
        return true
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(60)
                }
            }
        } catch (e: Exception) {
            // No vibrator - ignore.
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        waterAnimator.cancel()
        glowAnimator?.cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
