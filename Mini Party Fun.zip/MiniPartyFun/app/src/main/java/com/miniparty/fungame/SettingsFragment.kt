package com.miniparty.fungame

import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val radioGroup = view.findViewById<RadioGroup>(R.id.radio_theme)
        val radioSystem = view.findViewById<RadioButton>(R.id.radio_system)
        val radioDark = view.findViewById<RadioButton>(R.id.radio_dark)
        val radioLight = view.findViewById<RadioButton>(R.id.radio_light)

        when (Prefs.getThemeMode(requireContext())) {
            Prefs.MODE_DARK -> radioDark.isChecked = true
            Prefs.MODE_LIGHT -> radioLight.isChecked = true
            else -> radioSystem.isChecked = true
        }

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radio_dark -> Prefs.MODE_DARK
                R.id.radio_light -> Prefs.MODE_LIGHT
                else -> Prefs.MODE_SYSTEM
            }
            Prefs.setThemeMode(requireContext(), mode)
        }
    }
}
