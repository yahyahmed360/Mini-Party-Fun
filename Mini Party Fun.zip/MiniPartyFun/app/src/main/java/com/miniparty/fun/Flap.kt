package com.miniparty.fun

data class Flap(
    var name: String,
    var color: Int,
    var emoji: String
)

object DefaultFlaps {
    fun createDefault(): MutableList<Flap> = mutableListOf(
        Flap("New", 0xFF0D1B4C.toInt(), "☕"),
        Flap("New", 0xFF1B5E20.toInt(), "☕")
    )
}
