# Add project specific ProGuard rules here.

# Spin the Wheel (Room entities + libraries it depends on)
-keep class com.spinthewheel.app.data.db.entity.** { *; }
-dontwarn okhttp3.**
-dontwarn org.json.**
-dontwarn coil.**
-dontwarn okio.**
